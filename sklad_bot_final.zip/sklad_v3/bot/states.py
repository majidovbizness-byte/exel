from aiogram.fsm.state import State, StatesGroup

class Reg(StatesGroup):
    phone      = State()
    full_name  = State()
    password   = State()
    confirm_pw = State()

class Nak(StatesGroup):
    doc_type    = State()
    obj         = State()
    sender      = State()
    receiver    = State()
    vehicle     = State()
    veh_model   = State()
    driver      = State()
    destination = State()
    item        = State()
    item_search = State()
    item_unit   = State()
    item_qty    = State()
    more        = State()
    template    = State()
    fmt         = State()
    confirm     = State()

class OCR(StatesGroup):
    waiting_photo = State()
    confirm       = State()

class Calc(StatesGroup):
    expr = State()

class PwChange(StatesGroup):
    old_pw  = State()
    new_pw  = State()
    confirm = State()

class AdminUser(StatesGroup):
    phone    = State()
    name     = State()
    position = State()
    role     = State()

class AdminVeh(StatesGroup):
    plate  = State()
    model  = State()
    driver = State()

class AdminMat(StatesGroup):
    bulk   = State()
    search = State()

class AdminPlan(StatesGroup):
    choose_plan  = State()
    plan_name    = State()
    plan_desc    = State()
    plan_price   = State()
    plan_limit   = State()
    plan_formats = State()
    plan_funcs   = State()

class AdminSub(StatesGroup):
    phone      = State()
    choose_plan= State()

class AdminObj(StatesGroup):
    text = State()
