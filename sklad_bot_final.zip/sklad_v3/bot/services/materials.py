from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from bot.models import Material


async def by_code(s: AsyncSession, org_id: int, code: str) -> Material | None:
    code = code.strip().lstrip("0") or "0"
    r = await s.execute(select(Material).where(Material.organization_id == org_id, Material.code == code))
    return r.scalar_one_or_none()


async def search(s: AsyncSession, org_id: int, q: str, limit: int = 8) -> list[Material]:
    q = q.strip().casefold()
    r = await s.execute(select(Material).where(Material.organization_id == org_id))
    return [m for m in r.scalars() if q in m.name.casefold() or q in m.code.casefold()][:limit]


async def get(s: AsyncSession, mid: int) -> Material | None:
    return await s.get(Material, mid)
