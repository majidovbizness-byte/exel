import datetime
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from bot.models import NakCounter


async def next_number(s: AsyncSession, org_id: int) -> str:
    year = datetime.datetime.now().year
    r = await s.execute(
        select(NakCounter).where(NakCounter.organization_id == org_id, NakCounter.year == year).with_for_update()
    )
    c = r.scalar_one_or_none()
    if c is None:
        c = NakCounter(organization_id=org_id, year=year, last_num=0)
        s.add(c); await s.flush()
    c.last_num += 1
    await s.flush()
    return f"{c.last_num:04d}/{year}"
