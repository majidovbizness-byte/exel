"""
Qo'lyozma nakladnoy rasmini o'qish — Claude AI orqali.
Anthropic API kaliti .env da bo'lsa, rasm avtomatik tahlil qilinadi.
"""
import base64
import json
from bot.config import settings


async def ocr_nakladnaya(image_bytes: bytes) -> dict:
    """
    Rasm bytes → structured dict:
    {
      "object_text": "...",
      "sender": "...",
      "receiver": "...",
      "items": [{"code": "22551", "name": "Гайка М27", "unit": "кг", "quantity": "21,70"}, ...]
    }
    """
    if not settings.ANTHROPIC_API_KEY:
        raise ValueError("ANTHROPIC_API_KEY sozlanmagan.")

    try:
        import anthropic
    except ImportError:
        raise ImportError("anthropic kutubxonasi o'rnatilmagan. pip install anthropic")

    client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)

    img_b64 = base64.standard_b64encode(image_bytes).decode("utf-8")

    prompt = (
        "Bu qo'lyozma nakkladnoy (tovar o'tkazma hujjati) rasmi. "
        "Rasmdan quyidagi ma'lumotlarni aniqlab, faqat JSON formatida qaytaring:\n\n"
        "{\n"
        "  \"object_text\": \"Obyekt nomi yoki bo'sh satr\",\n"
        "  \"sender\": \"Jo'natuvchi yoki bo'sh satr\",\n"
        "  \"receiver\": \"Qabul qiluvchi yoki bo'sh satr\",\n"
        "  \"items\": [\n"
        "    {\"code\": \"kod yoki bo'sh\", \"name\": \"mahsulot nomi\", \"unit\": \"birlik\", \"quantity\": \"miqdor\"}\n"
        "  ]\n"
        "}\n\n"
        "Muhim:\n"
        "- Faqat JSON, boshqa hech narsa yozmang\n"
        "- Kodlar odatda 4-5 xonali raqam\n"
        "- 'кг', 'шт', 'литр', 'м' kabi birliklarni ruscha yozing\n"
        "- Miqdorlarni vergul bilan yozing (masalan: 21,70)\n"
        "- Agar o'qib bo'lmasa, bo'sh satr yozing"
    )

    message = client.messages.create(
        model="claude-opus-4-6",
        max_tokens=2000,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {"type": "base64", "media_type": "image/jpeg", "data": img_b64}
                },
                {"type": "text", "text": prompt}
            ]
        }]
    )

    raw = message.content[0].text.strip()
    # JSON tozalash
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip()

    data = json.loads(raw)
    return data
