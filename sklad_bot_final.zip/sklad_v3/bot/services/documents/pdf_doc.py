import asyncio, os, tempfile, uuid

TIMEOUT = 60

async def to_pdf(docx_path: str, out_dir: str) -> str:
    prof = os.path.join(tempfile.gettempdir(), f"lo_{uuid.uuid4().hex}")
    os.makedirs(prof, exist_ok=True)
    proc = await asyncio.create_subprocess_exec(
        "soffice", "--headless", "--norestore",
        f"-env:UserInstallation=file://{prof}",
        "--convert-to", "pdf", "--outdir", out_dir, docx_path,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    try:
        _, err = await asyncio.wait_for(proc.communicate(), timeout=TIMEOUT)
    except asyncio.TimeoutError:
        proc.kill(); await proc.wait()
        raise RuntimeError("PDF vaqt oshdi.")
    if proc.returncode != 0:
        raise RuntimeError(f"LibreOffice xato: {err.decode(errors='ignore')}")
    base = os.path.splitext(os.path.basename(docx_path))[0]
    pdf = os.path.join(out_dir, f"{base}.pdf")
    if not os.path.exists(pdf):
        raise RuntimeError("PDF yaratilmadi.")
    return pdf
