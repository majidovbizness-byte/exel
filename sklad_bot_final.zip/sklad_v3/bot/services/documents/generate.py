import os
from bot.models import Nakladnaya, PlanConfig
from bot.services.documents.excel_doc import build_excel
from bot.services.documents.word_doc import build_word
from bot.services.documents.pdf_doc import to_pdf

GEN = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../generated"))
os.makedirs(GEN, exist_ok=True)


async def generate(nak: Nakladnaya, org_name: str, fmt: str, cfg: PlanConfig | None, tpl: int = 1) -> str:
    safe = nak.number.replace("/", "-")

    if fmt == "excel":
        return build_excel(nak, org_name, os.path.join(GEN, f"nak_{safe}.xlsx"), tpl)

    docx = os.path.join(GEN, f"nak_{safe}.docx")
    build_word(nak, org_name, docx, tpl)

    if fmt == "word":
        return docx

    if fmt == "pdf":
        if cfg and not cfg.allow_pdf:
            return docx  # fallback
        return await to_pdf(docx, GEN)

    return build_excel(nak, org_name, os.path.join(GEN, f"nak_{safe}.xlsx"), tpl)
