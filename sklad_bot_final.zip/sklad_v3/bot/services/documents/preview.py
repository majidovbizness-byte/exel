"""
Накладной rasm ko'rinishi (PNG preview).
openpyxl bilan Excel yaratilib, Pillow bilan rasm sifatida chiqariladi.
LibreOffice mavjud bo'lsa, PDF orqali yuqori sifatli rasm olinadi.
Aks holda Pillow yordamida oddiy rasm shaklida jadval chiziladi.
"""
import io
from PIL import Image, ImageDraw, ImageFont
from bot.models import Nakladnaya


def _truncate(text: str, max_len: int) -> str:
    return text if len(text) <= max_len else text[:max_len - 1] + "…"


def build_preview(nak: Nakladnaya, org_name: str) -> bytes:
    """
    Накладной ni PNG rasmga aylantiradi.
    Qaytaradi: PNG bytes (Telegram'ga yuborish uchun).
    """
    WIDTH  = 900
    MARGIN = 30
    ROW_H  = 28
    HDR_H  = 200  # sarlavha balandligi
    MAX_ROWS = min(len(nak.items), 24)

    height = HDR_H + (MAX_ROWS + 2) * ROW_H + 80
    img = Image.new("RGB", (WIDTH, height), "white")
    draw = ImageDraw.Draw(img)

    # Font — standart fallback
    try:
        font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 20)
        font_hdr   = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 12)
        font_body  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11)
    except Exception:
        font_title = font_hdr = font_body = ImageFont.load_default()

    y = MARGIN

    # № va sana
    date_s = nak.created_at.strftime("%d.%m.%Y") if nak.created_at else "—"
    draw.text((MARGIN, y), f"№ {nak.number}", font=font_hdr, fill="#333333")
    draw.text((WIDTH - 200, y), date_s, font=font_hdr, fill="#333333")
    y += 28

    # Sarlavha
    title = "НАКЛАДНАЯ"
    bbox = draw.textbbox((0, 0), title, font=font_title)
    tw = bbox[2] - bbox[0]
    draw.text(((WIDTH - tw) // 2, y), title, font=font_title, fill="#1F4E79")
    y += 32
    sub = "на перемещение товаров, материалов"
    bbox2 = draw.textbbox((0, 0), sub, font=font_body)
    sw = bbox2[2] - bbox2[0]
    draw.text(((WIDTH - sw) // 2, y), sub, font=font_body, fill="#555555")
    y += 24

    # Chiziq
    draw.line([(MARGIN, y), (WIDTH - MARGIN, y)], fill="#1F4E79", width=2)
    y += 10

    # Meta ma'lumotlar
    meta = [
        f"Организация: {_truncate(org_name, 70)}",
        f"Объект: {_truncate(nak.object_text, 80)}",
        f"Отправитель: {nak.sender or '________________________'}",
        f"Получатель: {nak.receiver or '________________________'}",
    ]
    if nak.vehicle_plate or nak.driver:
        veh = f"{nak.vehicle_model} {nak.vehicle_plate}".strip()
        meta.append(f"Машина: {veh}   Водитель: {nak.driver or '___'}")
    if nak.destination:
        meta.append(f"Куда: {_truncate(nak.destination, 70)}")

    for line in meta:
        draw.text((MARGIN, y), line, font=font_body, fill="#222222")
        y += 20
    y += 8

    # Jadval chiziqlari
    COL_X = [MARGIN, MARGIN + 45, MARGIN + 110, MARGIN + 490, MARGIN + 600, WIDTH - MARGIN]

    # Jadval sarlavhasi
    draw.rectangle([(MARGIN, y), (WIDTH - MARGIN, y + ROW_H)], fill="#D6E4F0")
    headers = ["№", "Код", "Наименование товар, материалов", "Ед. изм.", "Кол-во"]
    for i, h in enumerate(headers):
        draw.text((COL_X[i] + 4, y + 7), h, font=font_hdr, fill="#1F4E79")
    y += ROW_H

    # Jadval qatorlari
    for idx in range(MAX_ROWS):
        bg = "#FAFCFF" if idx % 2 == 0 else "white"
        draw.rectangle([(MARGIN, y), (WIDTH - MARGIN, y + ROW_H)], fill=bg)
        it = nak.items[idx]
        vals = [str(it.row_no), it.code, _truncate(it.name, 48), it.unit, it.quantity]
        for i, v in enumerate(vals):
            draw.text((COL_X[i] + 4, y + 7), v, font=font_body, fill="#222222")
        y += ROW_H

    # Jadval chegaralari (gorizontal)
    # vertikal chiziqlar
    draw.line([(MARGIN, HDR_H - 10), (MARGIN, y)], fill="#AAAAAA", width=1)
    draw.line([(WIDTH - MARGIN, HDR_H - 10), (WIDTH - MARGIN, y)], fill="#AAAAAA", width=1)

    # Chegara
    draw.rectangle([(MARGIN - 1, MARGIN - 1), (WIDTH - MARGIN + 1, height - MARGIN + 1)],
                   outline="#1F4E79", width=2)

    # Imzo qatori
    y += 10
    draw.text((MARGIN, y), "Отпустил: ____________________________", font=font_body, fill="#222222")
    draw.text((WIDTH // 2, y), "Получил: ____________________________", font=font_body, fill="#222222")

    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()
