"""Excel generatori — 10 ta shablon."""
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from bot.models import Nakladnaya

T = Side(style="thin")
M = Side(style="medium")
BALL = Border(left=T, right=T, top=T, bottom=T)
BMED = Border(left=M, right=M, top=M, bottom=M)

TEMPLATES = {
    1: "Klassik",     2: "Ixcham",        3: "Korporativ",
    4: "Batafsil",    5: "Sodda",          6: "Mahsulot",
    7: "Transport",   8: "Ikki tilli",    9: "A5",
    10: "Qurilish",
}


def _c(ws, ref, val, sz=11, bold=False, italic=False,
       align="left", wrap=False, border=False, bg=None, font_color=None):
    c = ws[ref]; c.value = val
    c.font = Font(name="Arial", size=sz, bold=bold, italic=italic,
                  color=font_color or "000000")
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    if border: c.border = BALL
    if bg: c.fill = PatternFill("solid", fgColor=bg)
    return c


def _header_block(ws, org_name: str, nak: Nakladnaya, tpl: int):
    """Sarlavha bloki — shablonga qarab o'zgaradi."""
    date_s = nak.created_at.strftime("%d.%m.%Y") if nak.created_at else "__.__.__"

    # Birinchi qator: № va sana
    ws.merge_cells("A1:B1"); _c(ws, "A1", f"№ {nak.number}", sz=10)
    ws.merge_cells("D1:E1"); _c(ws, "D1", f"«__» _________ {date_s[:4]} йил", sz=10, align="right", italic=True)

    # Sarlavha
    ws.row_dimensions[2].height = 28
    ws.merge_cells("A2:E2")
    _c(ws, "A2", "НАКЛАДНАЯ", sz=18 if tpl != 9 else 14, bold=True, align="center",
       bg="1F4E79" if tpl == 3 else None, font_color="FFFFFF" if tpl == 3 else None)

    ws.merge_cells("A3:E3")
    _c(ws, "A3", "на перемещение товаров, материалов", sz=11, align="center")

    ws.merge_cells("A5:E5")
    _c(ws, "A5", f"Организация: {org_name}", sz=11, bold=True)

    ws.row_dimensions[6].height = 30
    ws.merge_cells("A6:E6")
    _c(ws, "A6", f"Объект: {nak.object_text}", sz=11, wrap=True)

    _sender   = nak.sender if nak.sender else "________________________"
    _receiver = nak.receiver if nak.receiver else "________________________"
    ws.merge_cells("A7:E7"); _c(ws, "A7", f"Отправитель: {_sender}", sz=11)
    ws.merge_cells("A8:E8"); _c(ws, "A8", f"Получатель: {_receiver}", sz=11)

    # Transport ma'lumoti (7-shablon kattaroq)
    if tpl == 7:
        ws.row_dimensions[9].height = 18
        ws.merge_cells("A9:E9")
        veh = f"{nak.vehicle_model} {nak.vehicle_plate}".strip() or "________________________"
        drv = nak.driver if nak.driver else "________________________"
        _c(ws, "A9", f"Машина: {veh}   Водитель: {drv}", sz=11)
    elif tpl != 2 and tpl != 9:
        ws.merge_cells("A9:E9")
        veh = f"{nak.vehicle_model} {nak.vehicle_plate}".strip() or "________________________"
        drv = nak.driver if nak.driver else "________________________"
        _c(ws, "A9", f"Машина: {veh}   Водитель: {drv}", sz=10)

    dest = nak.destination if nak.destination else "________________________"
    ws.merge_cells("A10:E10")
    _c(ws, "A10", f"Куда: {dest}", sz=10)


def build_excel(nak: Nakladnaya, org_name: str, path: str, tpl: int = 1) -> str:
    wb = Workbook(); ws = wb.active; ws.title = "Накладная"
    tpl = max(1, min(10, tpl))

    # Ustun kengliklar
    widths = {"A": 6, "B": 12, "C": 44, "D": 13, "E": 14}
    if tpl == 4:  # Batafsil
        widths = {"A": 5, "B": 11, "C": 40, "D": 10, "E": 12}
    if tpl == 9:  # A5
        widths = {"A": 4, "B": 9, "C": 32, "D": 8, "E": 10}
    for col, w in widths.items():
        ws.column_dimensions[col].width = w

    _header_block(ws, org_name, nak, tpl)

    # Jadval sarlavhasi
    HR = 11
    ws.row_dimensions[HR].height = 32
    headers = ["№\nп/п", "Бух.счет", "Наименование товар, материалов", "Единица\nизмерения", "Количество"]

    # 8-shablon: ikki tilli sarlavhalar
    if tpl == 8:
        headers = ["№", "Kod/Код", "Nom/Наименование", "Birlik/Ед.", "Miqdor/Кол-во"]

    # 10-shablon: qurilish
    if tpl == 10:
        headers = ["№\nп/п", "Бух.счет", "Наименование материала", "Ед.\nизм.", "Кол-во"]

    hdr_bg = "2F75B6" if tpl in (3, 7) else "D6E4F0" if tpl in (4, 8) else "F2F2F2"
    hdr_fc = "FFFFFF" if tpl in (3, 7) else "000000"
    for i, h in enumerate(headers):
        col = get_column_letter(i + 1)
        _c(ws, f"{col}{HR}", h, sz=10, bold=True, align="center", wrap=True,
           border=True, bg=hdr_bg, font_color=hdr_fc)

    # Ma'lumot qatorlari
    DR = HR + 1
    n_rows = max(24, len(nak.items))
    for r in range(n_rows):
        er = DR + r
        ws.row_dimensions[er].height = 20 if tpl != 5 else 24
        alt_bg = "F7FBFF" if (r % 2 == 0 and tpl == 4) else None
        _c(ws, f"A{er}", r + 1, align="center", border=True, bg=alt_bg)
        it = nak.items[r] if r < len(nak.items) else None
        _c(ws, f"B{er}", it.code     if it else "", align="center", border=True, bg=alt_bg)
        _c(ws, f"C{er}", it.name     if it else "", align="left",   border=True, wrap=True, bg=alt_bg)
        _c(ws, f"D{er}", it.unit     if it else "", align="center", border=True, bg=alt_bg)
        _c(ws, f"E{er}", it.quantity if it else "", align="center", border=True, bg=alt_bg)

    # Imzo qatori
    sr = DR + n_rows + 1
    ws.row_dimensions[sr].height = 22 if tpl != 5 else 32
    _c(ws, f"A{sr}", "Отпустил:", bold=True)
    ws.merge_cells(f"B{sr}:C{sr}")
    _c(ws, f"B{sr}", "______________________")
    _c(ws, f"D{sr}", "Получил:", bold=True)
    _c(ws, f"E{sr}", "______________")

    ws.print_area = f"A1:E{sr}"
    ws.page_setup.orientation = "portrait"
    ws.page_setup.fitToWidth = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True

    wb.save(path)
    return path
