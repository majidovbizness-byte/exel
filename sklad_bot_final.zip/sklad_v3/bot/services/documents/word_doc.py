from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt, RGBColor
from bot.models import Nakladnaya


def _tc(cell, text, bold=False, sz=10, align=WD_ALIGN_PARAGRAPH.LEFT, color=None):
    cell.text = ""
    p = cell.paragraphs[0]; p.alignment = align
    r = p.add_run(str(text) if text else "")
    r.bold = bold; r.font.size = Pt(sz); r.font.name = "Arial"
    if color: r.font.color.rgb = RGBColor(*color)


def build_word(nak: Nakladnaya, org_name: str, path: str, tpl: int = 1) -> str:
    doc = Document()
    s = doc.sections[0]
    s.left_margin = Cm(1.5); s.right_margin = Cm(1.5)
    s.top_margin = Cm(1.5);  s.bottom_margin = Cm(1.5)

    # Sarlavha
    t = doc.add_paragraph(); t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = t.add_run("НАКЛАДНАЯ"); r.bold = True; r.font.size = Pt(18)
    if tpl == 3: r.font.color.rgb = RGBColor(31, 78, 121)

    s2 = doc.add_paragraph(); s2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    s2.add_run("на перемещение товаров, материалов").font.size = Pt(11)

    date_s = nak.created_at.strftime("%d.%m.%Y") if nak.created_at else ""
    m = doc.add_paragraph(); m.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    ri = m.add_run(f"№ {nak.number}   от {date_s} г."); ri.italic = True; ri.font.size = Pt(10)

    doc.add_paragraph(f"Организация: {org_name}").runs[0].bold = True

    obj_p = doc.add_paragraph()
    obj_p.add_run(f"Объект: {nak.object_text}").font.size = Pt(11)

    sender   = nak.sender   if nak.sender   else "________________________"
    receiver = nak.receiver if nak.receiver else "________________________"
    driver   = nak.driver   if nak.driver   else "________________________"
    veh      = f"{nak.vehicle_model} {nak.vehicle_plate}".strip() or "________________________"
    dest     = nak.destination if nak.destination else "________________________"

    doc.add_paragraph(f"Отправитель: {sender}")
    doc.add_paragraph(f"Получатель: {receiver}")
    doc.add_paragraph(f"Машина: {veh}   Водитель: {driver}")
    doc.add_paragraph(f"Куда: {dest}")

    # Jadval
    n = max(len(nak.items), 1)
    tbl = doc.add_table(rows=n + 1, cols=5)
    tbl.style = "Table Grid"; tbl.alignment = WD_TABLE_ALIGNMENT.CENTER

    hdr_color = (31, 78, 121) if tpl == 3 else None
    for i, h in enumerate(["№", "Бух.счет", "Наименование товар, материалов", "Ед. изм.", "Кол-во"]):
        cell = tbl.rows[0].cells[i]
        _tc(cell, h, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, color=hdr_color)

    for idx, it in enumerate(nak.items, 1):
        row = tbl.rows[idx].cells
        _tc(row[0], idx, align=WD_ALIGN_PARAGRAPH.CENTER)
        _tc(row[1], it.code)
        _tc(row[2], it.name)
        _tc(row[3], it.unit, align=WD_ALIGN_PARAGRAPH.CENTER)
        _tc(row[4], it.quantity, align=WD_ALIGN_PARAGRAPH.CENTER)

    # Imzo
    doc.add_paragraph()
    sg = doc.add_table(rows=1, cols=2)
    _tc(sg.rows[0].cells[0], "Отпустил: ____________________", bold=True)
    _tc(sg.rows[0].cells[1], "Получил: ____________________", bold=True)

    doc.save(path)
    return path
