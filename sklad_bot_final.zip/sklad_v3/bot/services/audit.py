from sqlalchemy.ext.asyncio import AsyncSession
from bot.models import AuditLog


async def log(s: AsyncSession, user_id: int | None, org_id: int | None,
              action: str, detail: str = "", suspicious: bool = False):
    s.add(AuditLog(user_id=user_id, org_id=org_id, action=action,
                   detail=detail, suspicious=suspicious))
    await s.flush()


async def check_suspicious(s: AsyncSession, user_id: int, org_id: int) -> list[str]:
    """Shubhali harakatlarni tekshiradi."""
    import datetime as dt
    warnings = []
    now = dt.datetime.now(dt.timezone.utc)

    # 1. Tungi vaqtda ishlash (22:00 - 06:00)
    hour = now.hour
    if hour >= 22 or hour < 6:
        warnings.append(f"🌙 Tungi vaqtda ({now.strftime('%H:%M')}) nakladnoy yaratildi")

    # 2. So'nggi soatda 10 tadan ortiq nakladnoy
    from sqlalchemy import select, func
    from bot.models import Nakladnaya
    hour_ago = now - dt.timedelta(hours=1)
    r = await s.execute(
        select(func.count()).select_from(Nakladnaya).where(
            Nakladnaya.creator_id == user_id,
            Nakladnaya.created_at >= hour_ago
        )
    )
    count = r.scalar_one()
    if count >= 10:
        warnings.append(f"🔁 Bir soatda {count} ta nakladnoy yaratildi")

    return warnings
