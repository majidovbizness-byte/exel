"""Obuna va tarif konfiguratsiyasini olish."""
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from bot.models import PlanConfig, SubPlan, Subscription


async def get_sub(s: AsyncSession, org_id: int) -> Subscription | None:
    r = await s.execute(select(Subscription).where(Subscription.organization_id == org_id))
    return r.scalar_one_or_none()


async def get_plan_cfg(s: AsyncSession, org_id: int, plan: SubPlan) -> PlanConfig | None:
    r = await s.execute(select(PlanConfig).where(
        PlanConfig.organization_id == org_id, PlanConfig.plan == plan
    ))
    return r.scalar_one_or_none()


async def get_all_cfgs(s: AsyncSession, org_id: int) -> list[PlanConfig]:
    r = await s.execute(select(PlanConfig).where(PlanConfig.organization_id == org_id))
    return list(r.scalars())


async def current_cfg(s: AsyncSession, org_id: int) -> PlanConfig | None:
    sub = await get_sub(s, org_id)
    if not sub:
        return None
    return await get_plan_cfg(s, org_id, sub.plan)


async def ensure_default_plans(s: AsyncSession, org_id: int):
    """Agar tarif konfiguratsiyalari bo'lmasa, standart qiymatlar bilan yaratadi."""
    existing = await get_all_cfgs(s, org_id)
    existing_plans = {c.plan for c in existing}

    defaults = [
        PlanConfig(
            organization_id=org_id, plan=SubPlan.BASIC,
            name="Asosiy", description="Boshlang'ich tarif",
            price=150000, doc_limit=10,
            allow_excel=True, allow_word=False, allow_pdf=False,
            allow_ocr=False, allow_report=False, allow_transport=False,
            allow_calc=True, allow_templates=2, unlimited=False,
            # Gemini AI — Asosiy: hech biri yoq
            allow_ai_calc=False, allow_ai_chat=False, allow_ai_search=False,
            allow_ai_report=False, allow_ai_anomaly=False, allow_ai_briefing=False,
            allow_ai_voice=False, allow_ai_translate=False,
        ),
        PlanConfig(
            organization_id=org_id, plan=SubPlan.STANDARD,
            name="Standart", description="O'rta tarif",
            price=300000, doc_limit=100,
            allow_excel=True, allow_word=True, allow_pdf=False,
            allow_ocr=False, allow_report=True, allow_transport=True,
            allow_calc=True, allow_templates=5, unlimited=False,
            # Gemini AI — Standart: asosiy AI funksiyalar
            allow_ai_calc=True, allow_ai_chat=False, allow_ai_search=True,
            allow_ai_report=True, allow_ai_anomaly=False, allow_ai_briefing=False,
            allow_ai_voice=False, allow_ai_translate=False,
        ),
        PlanConfig(
            organization_id=org_id, plan=SubPlan.PREMIUM,
            name="Premium", description="To'liq tarif",
            price=500000, doc_limit=999,
            allow_excel=True, allow_word=True, allow_pdf=True,
            allow_ocr=True, allow_report=True, allow_transport=True,
            allow_calc=True, allow_templates=10, unlimited=True,
            # Gemini AI — Premium: barcha AI funksiyalar
            allow_ai_calc=True, allow_ai_chat=True, allow_ai_search=True,
            allow_ai_report=True, allow_ai_anomaly=True, allow_ai_briefing=True,
            allow_ai_voice=True, allow_ai_translate=True,
        ),
    ]
    for d in defaults:
        if d.plan not in existing_plans:
            s.add(d)
    await s.flush()
