"""
Gemini AI xizmati — barcha AI funksiyalar shu yerda.
Google AI Studio bepul API kaliti bilan ishlaydi.
"""
import base64
import json
import re
from bot.config import settings


def _client():
    """Gemini client yaratadi."""
    if not settings.GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY sozlanmagan. .env faylga qo'shing.")
    try:
        import google.generativeai as genai
        genai.configure(api_key=settings.GEMINI_API_KEY)
        return genai.GenerativeModel("gemini-2.5-flash")
    except ImportError:
        raise ImportError("google-generativeai o'rnatilmagan: pip install google-generativeai")


def _clean_json(raw: str) -> str:
    """Gemini javobidan JSON ni tozalaydi."""
    raw = raw.strip()
    if raw.startswith("```"):
        parts = raw.split("```")
        raw = parts[1] if len(parts) > 1 else raw
        if raw.startswith("json"):
            raw = raw[4:]
    return raw.strip()


# ─────────────────────────────────────────────────────────────
# 1. Rasm → Nakladnoy (OCR)
# ─────────────────────────────────────────────────────────────

async def ocr_nakladnaya(image_bytes: bytes) -> dict:
    """
    Qo'lyozma nakladnoy rasmini o'qib JSON qaytaradi.
    """
    import asyncio
    import google.generativeai as genai
    from PIL import Image
    import io

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    img = Image.open(io.BytesIO(image_bytes))

    prompt = (
        "Bu qo'lyozma nakladnoy (tovar o'tkazma hujjati) rasmi. "
        "Rasmdan ma'lumotlarni o'qib FAQAT JSON formatida qaytaring:\n\n"
        "{\n"
        '  "object_text": "Obyekt nomi yoki boʼsh",\n'
        '  "sender": "Joʼnatuvchi yoki boʼsh",\n'
        '  "receiver": "Qabul qiluvchi yoki boʼsh",\n'
        '  "items": [\n'
        '    {"code": "kod (4-5 raqam) yoki boʼsh", "name": "mahsulot nomi", '
        '"unit": "birlik (кг/шт/м/литр)", "quantity": "miqdor"}\n'
        "  ]\n"
        "}\n\n"
        "Qoidalar:\n"
        "- Faqat JSON, boshqa hech narsa yozma\n"
        "- Miqdorlarni vergul bilan yoz: 21,70\n"
        "- Birliklarni ruscha yoz: кг, шт, м, литр, м²\n"
        "- O'qib bo'lmasa bo'sh qoldir"
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content([prompt, img]))
    data = json.loads(_clean_json(response.text))
    return data


# ─────────────────────────────────────────────────────────────
# 2. AI Kalkulator
# ─────────────────────────────────────────────────────────────

async def ai_calculate(expression: str) -> str:
    """
    Tabiiy tilda matematik va mantiqiy hisob-kitob.
    Masalan: "100 metr truba uchun har 5 metrda bitta fitings kerak, nechta?"
    """
    import asyncio
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    prompt = (
        "Siz qurilish va omborxona hisob-kitoblari bo'yicha mutaxassissiz.\n"
        "Quyidagi so'rovni hal qiling:\n\n"
        f"{expression}\n\n"
        "Qoidalar:\n"
        "- Javobni qisqa va aniq bering\n"
        "- Hisob jarayonini qisqacha ko'rsating\n"
        "- Natijani katta harflar bilan ajrating\n"
        "- O'zbek tilida javob bering\n"
        "- Agar matematik ifoda bo'lsa, aniq hisoblang\n"
        "- Agar savol bo'lsa, qurilish/ombor kontekstida javob bering"
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content(prompt))
    return response.text.strip()


# ─────────────────────────────────────────────────────────────
# 3. Aqlli suhbat — nakladnoy yaratish
# ─────────────────────────────────────────────────────────────

async def ai_parse_nakladnoy(user_message: str, materials_context: str = "") -> dict:
    """
    Foydalanuvchi bir xabarda hamma ma'lumotni aytsa,
    Gemini strukturalangan dict qaytaradi.
    """
    import asyncio
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    prompt = (
        "Siz omborxona nakladnoy tizimisiz. Foydalanuvchi xabaridan "
        "nakladnoy ma'lumotlarini ajratib oling.\n\n"
        f"Mavjud mahsulotlar bazasidan namuna:\n{materials_context}\n\n"
        f"Foydalanuvchi xabari: {user_message}\n\n"
        "FAQAT JSON formatida qaytaring:\n"
        "{\n"
        '  "sender": "joʼnatuvchi yoki boʼsh",\n'
        '  "receiver": "qabul qiluvchi yoki boʼsh",\n'
        '  "vehicle_plate": "mashina raqami yoki boʼsh",\n'
        '  "vehicle_model": "mashina rusumi yoki boʼsh",\n'
        '  "driver": "haydovchi yoki boʼsh",\n'
        '  "destination": "manzil yoki boʼsh",\n'
        '  "items": [\n'
        '    {"code": "kod", "name": "nom", "unit": "birlik", "quantity": "miqdor"}\n'
        "  ],\n"
        '  "missing": ["yetishmayotgan maydonlar ro\'yxati"]\n'
        "}"
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content(prompt))
    return json.loads(_clean_json(response.text))


# ─────────────────────────────────────────────────────────────
# 4. Aqlli mahsulot qidiruv
# ─────────────────────────────────────────────────────────────

async def ai_search_material(query: str, materials: list) -> list:
    """
    Xato yozilgan yoki noaniq so'rov bo'lsa ham topadi.
    materials = [{"code": "22551", "name": "Гайка М27", "unit": "кг"}, ...]
    """
    import asyncio
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    mat_list = "\n".join(f"{m['code']} | {m['name']} | {m['unit']}" for m in materials[:100])

    prompt = (
        f"Foydalanuvchi izlayapti: '{query}'\n\n"
        f"Mahsulotlar ro'yxati:\n{mat_list}\n\n"
        "Eng mos keladigan mahsulotlarning kodlarini toping. "
        "Xato yozilgan bo'lsa ham, o'xshash ma'noni ham hisobga oling. "
        "FAQAT JSON massiv qaytaring:\n"
        '["22551", "9375"]'
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content(prompt))
    codes = json.loads(_clean_json(response.text))
    return [m for m in materials if m.get("code") in codes][:8]


# ─────────────────────────────────────────────────────────────
# 5. Tabiiy tilda hisobot
# ─────────────────────────────────────────────────────────────

async def ai_generate_report(report_data: dict) -> str:
    """
    Statistika ma'lumotlaridan o'zbek tilida tahliliy hisobot yozadi.
    """
    import asyncio
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    prompt = (
        "Siz omborxona menejeri uchun hisobot yozuvchisisiz.\n\n"
        f"Statistika ma'lumotlari:\n{json.dumps(report_data, ensure_ascii=False, indent=2)}\n\n"
        "Quyidagilarni o'z ichiga olgan qisqa tahliliy hisobot yozing:\n"
        "1. Asosiy natijalar (2-3 gap)\n"
        "2. Eng faol xodim\n"
        "3. Eng ko'p chiqarilgan mahsulot\n"
        "4. Diqqatga sazovor jihatlar\n"
        "5. Tavsiya (1 ta)\n\n"
        "Tillar: O'zbekcha, qisqa va aniq, emoji ishlating"
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content(prompt))
    return response.text.strip()


# ─────────────────────────────────────────────────────────────
# 6. Anomaliya aniqlash
# ─────────────────────────────────────────────────────────────

async def ai_check_anomaly(user_name: str, actions: list) -> str | None:
    """
    Xodimning so'nggi harakatlarini tahlil qiladi.
    Shubhali bo'lsa — tavsif qaytaradi, yo'q bo'lsa — None.
    actions = [{"action": "nak_create", "detail": "0001/2026", "time": "02:35"}, ...]
    """
    if not actions:
        return None

    import asyncio
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    actions_text = "\n".join(
        f"- {a.get('time','')} | {a.get('action','')} | {a.get('detail','')}"
        for a in actions[-20:]
    )

    prompt = (
        f"Omborxona xodimi: {user_name}\n"
        f"So'nggi harakatlari:\n{actions_text}\n\n"
        "Quyidagi shubhali holatlarga e'tibor bering:\n"
        "- Tungi vaqtda (22:00-06:00) ish\n"
        "- Bir soatda 10+ nakladnoy\n"
        "- Bir xil mahsulot ketma-ket ko'p chiqarish\n"
        "- G'ayritabiiy katta miqdorlar\n\n"
        "Agar shubhali holat bo'lsa — qisqa tavsif yoz (1-2 gap, o'zbekcha).\n"
        "Agar shubhali holat yo'q bo'lsa — faqat 'OK' yoz."
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content(prompt))
    result = response.text.strip()
    return None if result.upper() == "OK" else result


# ─────────────────────────────────────────────────────────────
# 7. Kunlik brifing
# ─────────────────────────────────────────────────────────────

async def ai_daily_briefing(stats: dict) -> str:
    """
    Admin uchun kunlik brifing xabari yaratadi.
    """
    import asyncio
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    prompt = (
        "Omborxona boshqaruv tizimi uchun kunlik brifing xabari yozing.\n\n"
        f"Bugungi statistika:\n{json.dumps(stats, ensure_ascii=False, indent=2)}\n\n"
        "Xabar quyidagilarni o'z ichiga olsin:\n"
        "📊 Bugungi nakladnoylar soni\n"
        "👤 Eng faol xodim\n"
        "📦 Eng ko'p chiqarilgan mahsulot\n"
        "⚠️ Shubhali holat (bo'lsa)\n"
        "💡 Qisqa tavsiya\n\n"
        "O'zbekcha, emoji bilan, 8-10 qator."
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content(prompt))
    return response.text.strip()


# ─────────────────────────────────────────────────────────────
# 8. Ovozli buyruq (matnga aylantirish)
# ─────────────────────────────────────────────────────────────

async def ai_voice_to_nakladnoy(voice_text: str, materials_context: str = "") -> dict:
    """
    Ovozdan matn → nakladnoy ma'lumotlari.
    Telegram voice → aiogram text → bu funksiya.
    """
    return await ai_parse_nakladnoy(voice_text, materials_context)


# ─────────────────────────────────────────────────────────────
# 9. Ko'p til — tarjima
# ─────────────────────────────────────────────────────────────

async def ai_translate(text: str, target_lang: str = "uz") -> str:
    """
    Matnni maqsadli tilga tarjima qiladi.
    target_lang: "uz" (o'zbek), "ru" (rus), "tg" (tojik)
    """
    import asyncio
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    lang_names = {"uz": "o'zbek", "ru": "rus", "tg": "tojik"}
    lang_name = lang_names.get(target_lang, "o'zbek")

    prompt = (
        f"Quyidagi matnni {lang_name} tiliga tarjima qiling.\n"
        "Faqat tarjimani yozing, boshqa hech narsa qo'shmang:\n\n"
        f"{text}"
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content(prompt))
    return response.text.strip()


# ─────────────────────────────────────────────────────────────
# 10. Shablon tavsiyasi
# ─────────────────────────────────────────────────────────────

async def ai_suggest_template(items: list) -> int:
    """
    Mahsulotlar ro'yxatiga qarab eng mos shablonni tavsiya qiladi.
    1-10 orasida shablon ID qaytaradi.
    """
    import asyncio
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-2.5-flash")

    items_text = "\n".join(f"- {it.get('name','')} ({it.get('unit','')})" for it in items[:10])

    templates = (
        "1=Klassik, 2=Ixcham, 3=Korporativ, 4=Batafsil, 5=Sodda, "
        "6=Mahsulot-markazlashgan, 7=Transport katta, 8=Ikki tilli, "
        "9=A5 kichik, 10=Qurilish"
    )

    prompt = (
        f"Quyidagi mahsulotlar uchun eng mos shablon raqamini toping:\n{items_text}\n\n"
        f"Shablonlar: {templates}\n\n"
        "FAQAT raqam qaytaring (1-10):"
    )

    loop = asyncio.get_event_loop()
    response = await loop.run_in_executor(None, lambda: model.generate_content(prompt))
    try:
        return int(response.text.strip())
    except Exception:
        return 1
