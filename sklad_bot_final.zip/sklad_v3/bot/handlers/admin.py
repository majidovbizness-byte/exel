"""To'liq administrator paneli."""
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import func, select

from bot import texts as T
from bot.keyboards import (admin_menu_kb, ai_funcs_kb, back_to_admin, formats_choice_kb,
                           funcs_choice_kb, mat_menu_kb,
                           plan_edit_kb, plans_display_kb, users_menu_kb)
from bot.models import (AllowedPhone, AuditLog, Material, Nakladnaya,
                        Organization, SubPlan, Subscription,
                        SubStatus, User, UserRole, Vehicle)
from bot.services import materials as mat_svc
from bot.services.audit import log
from bot.services.subscription import (ensure_default_plans, get_all_cfgs,
                                        get_plan_cfg, get_sub)
from bot.states import AdminMat, AdminObj, AdminPlan, AdminSub, AdminUser, AdminVeh

router = Router(name="admin")


def _adm(u: User) -> bool:
    return u.role in (UserRole.ADMIN, UserRole.SUPER_ADMIN)


# ══════════════ ASOSIY MENYU ══════════════

@router.message(F.text == "🛠 Admin panel")
async def adm_menu(message: Message, db_user: User):
    if not _adm(db_user):
        await message.answer(T.ONLY_ADMIN, parse_mode="HTML"); return
    await message.answer(T.ADM_MENU, reply_markup=admin_menu_kb(), parse_mode="HTML")


@router.callback_query(F.data == "adm:back")
async def adm_back(cb: CallbackQuery, db_user: User):
    await cb.message.edit_text(T.ADM_MENU, reply_markup=admin_menu_kb(), parse_mode="HTML")
    await cb.answer()


# ══════════════ FOYDALANUVCHILAR ══════════════

@router.callback_query(F.data == "adm:users")
async def adm_users(cb: CallbackQuery, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    await cb.message.edit_text("👥 <b>Foydalanuvchilar boshqaruvi</b>",
                               reply_markup=users_menu_kb(), parse_mode="HTML")
    await cb.answer()


@router.callback_query(F.data == "usr:add")
async def usr_add(cb: CallbackQuery, state: FSMContext, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    await state.set_state(AdminUser.phone)
    await cb.message.edit_text("📱 Yangi xodim telefon raqami:")
    await cb.answer()


@router.message(AdminUser.phone)
async def usr_add_ph(message: Message, state: FSMContext):
    await state.update_data(phone=message.text.strip())
    await state.set_state(AdminUser.name)
    await message.answer("👤 To'liq F.I.Sh:")


@router.message(AdminUser.name)
async def usr_add_nm(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(AdminUser.position)
    await message.answer("💼 Lavozimi (bo'sh qoldirish mumkin — '.' yuboring):")


@router.message(AdminUser.position)
async def usr_add_pos(message: Message, state: FSMContext):
    pos = "" if message.text.strip() == "." else message.text.strip()
    await state.update_data(position=pos)
    await state.set_state(AdminUser.role)
    from aiogram.types import InlineKeyboardButton as IB, InlineKeyboardMarkup as IM
    kb = IM(inline_keyboard=[
        [IB(text="👷 Xodim",         callback_data="urole:employee")],
        [IB(text="📊 Rahbar",         callback_data="urole:manager")],
        [IB(text="🛠 Administrator",  callback_data="urole:admin")],
    ])
    await message.answer("🔑 Rolini tanlang:", reply_markup=kb)


@router.callback_query(AdminUser.role, F.data.startswith("urole:"))
async def usr_add_role(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    role = cb.data.split(":", 1)[1]
    data = await state.get_data()
    r = await session.execute(select(AllowedPhone).where(AllowedPhone.phone_number == data["phone"]))
    if r.scalar_one_or_none():
        await cb.message.edit_text("⚠️ Bu raqam allaqachon mavjud.")
        await state.clear(); await cb.answer(); return
    session.add(AllowedPhone(organization_id=db_user.organization_id, phone_number=data["phone"],
                             full_name=data["name"], role=UserRole(role), position=data.get("position","")))
    await log(session, db_user.id, db_user.organization_id, "user_add", data["phone"])
    await session.commit(); await state.clear()
    await cb.message.edit_text(
        f"✅ <b>{data['name']}</b> ({data['phone']}) qo'shildi.\n"
        "U /start yuborib, telefon ulashsa avtomatik kiradi.", parse_mode="HTML")
    await cb.answer()


@router.callback_query(F.data == "usr:list")
async def usr_list(cb: CallbackQuery, session, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    r = await session.execute(select(User).where(
        User.organization_id == db_user.organization_id).order_by(User.full_name))
    users = r.scalars().all()
    if not users:
        await cb.message.edit_text("Xodimlar ro'yxati bo'sh."); await cb.answer(); return
    lines = ["👥 <b>Xodimlar ro'yxati:</b>\n"]
    for u in users:
        ico  = "🟢" if u.is_active and not u.is_frozen else ("⏸" if u.is_frozen else "🔴")
        role = {"super_admin":"👑","admin":"🛠","manager":"📊","employee":"👷"}.get(u.role.value,"")
        seen = u.last_seen.strftime("%d.%m %H:%M") if u.last_seen else "—"
        lines.append(f"{ico}{role} <b>{u.full_name}</b>\n"
                     f"   🔑 {u.username} | 📱 {u.phone}\n"
                     f"   👁 {seen}\n")
    await cb.message.edit_text("\n".join(lines), parse_mode="HTML", reply_markup=back_to_admin())
    await cb.answer()


@router.callback_query(F.data.in_({"usr:block_menu", "usr:unblock_menu", "usr:freeze_menu"}))
async def usr_action_menu(cb: CallbackQuery, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    action = cb.data.split(":")[1].replace("_menu","")
    cmds = {"block": "/block", "unblock": "/unblock", "freeze": "/freeze"}
    await cb.message.edit_text(
        f"Telefon raqamini kiriting:\n<code>{cmds[action]} +998901234567</code>",
        parse_mode="HTML")
    await cb.answer()


@router.callback_query(F.data == "usr:stats")
async def usr_stats(cb: CallbackQuery, session, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    r = await session.execute(
        select(Nakladnaya.creator_id, func.count()).where(
            Nakladnaya.organization_id == db_user.organization_id)
        .group_by(Nakladnaya.creator_id))
    rows = r.all()
    lines = ["📈 <b>Xodim statistikasi (jami):</b>\n"]
    for uid, cnt in sorted(rows, key=lambda x: x[1], reverse=True):
        u = await session.get(User, uid)
        name = u.full_name if u else f"#{uid}"
        lines.append(f"  👤 {name}: <b>{cnt} ta</b>")
    await cb.message.edit_text("\n".join(lines) if rows else "Ma'lumot yo'q.",
                               parse_mode="HTML", reply_markup=back_to_admin())
    await cb.answer()


@router.callback_query(F.data == "usr:rating")
async def usr_rating(cb: CallbackQuery, session, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    import datetime
    month_start = datetime.datetime.now().replace(day=1, hour=0, minute=0, second=0)
    r = await session.execute(
        select(Nakladnaya.creator_id, func.count()).where(
            Nakladnaya.organization_id == db_user.organization_id,
            Nakladnaya.created_at >= month_start)
        .group_by(Nakladnaya.creator_id))
    rows = sorted(r.all(), key=lambda x: x[1], reverse=True)
    medals = ["🥇", "🥈", "🥉"]
    lines = ["🏆 <b>Bu oylik reyting:</b>\n"]
    for i, (uid, cnt) in enumerate(rows):
        u = await session.get(User, uid)
        icon = medals[i] if i < 3 else f"{i+1}."
        lines.append(f"{icon} {u.full_name if u else uid}: <b>{cnt} ta</b>")
    await cb.message.edit_text("\n".join(lines) if rows else "Bu oy hali nakladnoy yo'q.",
                               parse_mode="HTML", reply_markup=back_to_admin())
    await cb.answer()


@router.message(Command("block"))
async def block(message: Message, session, db_user: User):
    if not _adm(db_user): return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2: await message.answer("Foydalanish: /block <telefon>"); return
    r = await session.execute(select(User).where(User.phone == parts[1].strip()))
    u = r.scalar_one_or_none()
    if not u: await message.answer("Topilmadi."); return
    u.is_active = False
    await log(session, db_user.id, db_user.organization_id, "user_block", parts[1])
    await session.commit()
    await message.answer(f"🔴 <b>{u.full_name}</b> bloklandi.", parse_mode="HTML")


@router.message(Command("unblock"))
async def unblock(message: Message, session, db_user: User):
    if not _adm(db_user): return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2: await message.answer("Foydalanish: /unblock <telefon>"); return
    r = await session.execute(select(User).where(User.phone == parts[1].strip()))
    u = r.scalar_one_or_none()
    if not u: await message.answer("Topilmadi."); return
    u.is_active = True; u.is_frozen = False
    await log(session, db_user.id, db_user.organization_id, "user_unblock", parts[1])
    await session.commit()
    await message.answer(f"🟢 <b>{u.full_name}</b> blokdan chiqarildi.", parse_mode="HTML")


@router.message(Command("freeze"))
async def freeze(message: Message, session, db_user: User):
    if not _adm(db_user): return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2: await message.answer("Foydalanish: /freeze <telefon>"); return
    r = await session.execute(select(User).where(User.phone == parts[1].strip()))
    u = r.scalar_one_or_none()
    if not u: await message.answer("Topilmadi."); return
    u.is_frozen = True
    await log(session, db_user.id, db_user.organization_id, "user_freeze", parts[1])
    await session.commit()
    await message.answer(f"⏸ <b>{u.full_name}</b> tekshiruv rejimiga qo'yildi.", parse_mode="HTML")


# ══════════════ MAHSULOT BAZASI ══════════════

@router.callback_query(F.data == "adm:mat")
async def adm_mat(cb: CallbackQuery, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    await cb.message.edit_text("📦 <b>Mahsulot bazasi</b>",
                               reply_markup=mat_menu_kb(), parse_mode="HTML")
    await cb.answer()


@router.callback_query(F.data == "mat:bulk")
async def mat_bulk_start(cb: CallbackQuery, state: FSMContext, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    await state.set_state(AdminMat.bulk)
    await cb.message.edit_text(
        "📥 <b>Ko'plab mahsulot qo'shish:</b>\n\n"
        "Format: <code>kod;nom;birlik</code>\n\n"
        "Misol:\n"
        "<code>22551;Гайка М27;кг\n"
        "9375;Шайба М 27;кг\n"
        "0468;Диск церкулярный Д180;шт</code>",
        parse_mode="HTML"); await cb.answer()


@router.message(AdminMat.bulk)
async def mat_bulk(message: Message, state: FSMContext, session, db_user: User):
    added = updated = 0; errors = []
    for line in message.text.split("\n"):
        line = line.strip()
        if not line: continue
        parts = [p.strip() for p in line.split(";")]
        if len(parts) != 3: errors.append(line); continue
        code, name, unit = parts
        ex = await mat_svc.by_code(session, db_user.organization_id, code)
        if ex: ex.name = name; ex.unit = unit; updated += 1
        else:
            session.add(Material(organization_id=db_user.organization_id, code=code, name=name, unit=unit))
            added += 1
    await log(session, db_user.id, db_user.organization_id, "mat_bulk", f"+{added}~{updated}")
    await session.commit(); await state.clear()
    txt = f"✅ Qo'shildi: <b>{added} ta</b>\n♻️ Yangilandi: <b>{updated} ta</b>"
    if errors: txt += f"\n\n⚠️ Xato qatorlar ({len(errors)}):\n" + "\n".join(errors[:5])
    await message.answer(txt, parse_mode="HTML")


@router.callback_query(F.data == "mat:search")
async def mat_search_start(cb: CallbackQuery, state: FSMContext, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    await state.set_state(AdminMat.search)
    await cb.message.edit_text("🔍 Kod yoki nom kiriting:"); await cb.answer()


@router.message(AdminMat.search)
async def mat_search(message: Message, state: FSMContext, session, db_user: User):
    q = message.text.strip()
    by_code = await mat_svc.by_code(session, db_user.organization_id, q)
    results = ([by_code] if by_code else []) + await mat_svc.search(session, db_user.organization_id, q, 15)
    await state.clear()
    if not results: await message.answer("Hech narsa topilmadi."); return
    lines = [f"<code>{m.code or '—'}</code> | {m.name} | {m.unit}" for m in results[:15]]
    await message.answer("\n".join(lines), parse_mode="HTML")


@router.callback_query(F.data == "mat:stats")
async def mat_stats(cb: CallbackQuery, session, db_user: User):
    r = await session.execute(select(func.count()).select_from(Material).where(
        Material.organization_id == db_user.organization_id))
    count = r.scalar_one()
    await cb.message.edit_text(f"📊 Bazada jami: <b>{count} ta</b> mahsulot.",
                               parse_mode="HTML", reply_markup=back_to_admin())
    await cb.answer()


@router.callback_query(F.data == "mat:delete")
async def mat_del_info(cb: CallbackQuery):
    await cb.message.edit_text("O'chirish uchun: <code>/ochir_kod 22551</code>", parse_mode="HTML")
    await cb.answer()


@router.message(Command("ochir_kod"))
async def del_mat(message: Message, session, db_user: User):
    if not _adm(db_user): return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2: await message.answer("Foydalanish: /ochir_kod <kod>"); return
    m = await mat_svc.by_code(session, db_user.organization_id, parts[1])
    if not m: await message.answer("Topilmadi."); return
    await session.delete(m)
    await log(session, db_user.id, db_user.organization_id, "mat_delete", parts[1])
    await session.commit()
    await message.answer(f"🗑 <code>{parts[1]}</code> o'chirildi.", parse_mode="HTML")


# ══════════════ TRANSPORT ══════════════

@router.callback_query(F.data == "adm:veh")
async def adm_veh(cb: CallbackQuery, state: FSMContext, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    await state.set_state(AdminVeh.plate)
    await cb.message.edit_text("🚛 Yangi mashina davlat raqami:"); await cb.answer()


@router.message(AdminVeh.plate)
async def veh_pl(message: Message, state: FSMContext):
    await state.update_data(plate=message.text.strip())
    await state.set_state(AdminVeh.model)
    await message.answer("🚛 Mashina rusumi:")


@router.message(AdminVeh.model)
async def veh_mod(message: Message, state: FSMContext):
    await state.update_data(model=message.text.strip())
    await state.set_state(AdminVeh.driver)
    await message.answer("👨‍✈️ Haydovchi F.I.Sh:")


@router.message(AdminVeh.driver)
async def veh_drv(message: Message, state: FSMContext, session, db_user: User):
    data = await state.get_data()
    r = await session.execute(select(Vehicle).where(
        Vehicle.organization_id == db_user.organization_id, Vehicle.plate == data["plate"]))
    if r.scalar_one_or_none():
        await message.answer("⚠️ Bu raqam allaqachon mavjud."); await state.clear(); return
    session.add(Vehicle(organization_id=db_user.organization_id,
                        plate=data["plate"], model=data["model"], driver=message.text.strip()))
    await session.commit(); await state.clear()
    await message.answer(f"✅ <b>{data['plate']}</b> bazaga qo'shildi.", parse_mode="HTML")


# ══════════════ TARIF SOZLAMALARI ══════════════

@router.callback_query(F.data == "adm:plans")
async def adm_plans(cb: CallbackQuery, session, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    await ensure_default_plans(session, db_user.organization_id)
    await session.commit()
    cfgs = await get_all_cfgs(session, db_user.organization_id)
    lines = ["⚙️ <b>Tarif sozlamalari</b>\n\nTahrirlamoqchi bo'lgan tarifni tanlang:"]
    from aiogram.types import InlineKeyboardButton as IB, InlineKeyboardMarkup as IM
    rows = [[IB(text=f"{'📋' if c.plan==SubPlan.BASIC else '📊' if c.plan==SubPlan.STANDARD else '🏆'} "
                    f"{c.name} — {c.price:,.0f} {c.currency} | Limit: {'∞' if c.unlimited else c.doc_limit}",
                callback_data=f"plan_edit:{c.plan.value}")]
            for c in cfgs]
    rows.append([IB(text="🔙 Admin panel", callback_data="adm:back")])
    await cb.message.edit_text("\n".join(lines), reply_markup=IM(inline_keyboard=rows), parse_mode="HTML")
    await cb.answer()


@router.callback_query(F.data.startswith("plan_edit:"))
async def plan_edit(cb: CallbackQuery, session, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    plan = SubPlan(cb.data.split(":", 1)[1])
    cfg = await get_plan_cfg(session, db_user.organization_id, plan)
    if not cfg:
        await cb.answer("Topilmadi."); return

    info = (
        f"⚙️ <b>{cfg.name}</b> tarif sozlamalari:\n\n"
        f"💰 Narx: {cfg.price:,.0f} {cfg.currency}\n"
        f"🔢 Limit: {'∞' if cfg.unlimited else f'{cfg.doc_limit} ta'}\n"
        f"📊 Excel: {'✅' if cfg.allow_excel else '❌'} | "
        f"📄 Word: {'✅' if cfg.allow_word else '❌'} | "
        f"🧾 PDF: {'✅' if cfg.allow_pdf else '❌'}\n"
        f"📸 OCR: {'✅' if cfg.allow_ocr else '❌'} | "
        f"📊 Hisobot: {'✅' if cfg.allow_report else '❌'} | "
        f"🚛 Transport: {'✅' if cfg.allow_transport else '❌'}\n"
        f"📋 Shablonlar: {cfg.allow_templates} ta | "
        f"🧮 Hisoblash: {'✅' if cfg.allow_calc else '❌'}"
    )
    await cb.message.edit_text(info, reply_markup=plan_edit_kb(plan), parse_mode="HTML")
    await cb.answer()


@router.callback_query(F.data.startswith("pe:"))
async def plan_field_edit(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    parts = cb.data.split(":")
    field, plan_val = parts[1], parts[2]
    plan = SubPlan(plan_val)
    cfg = await get_plan_cfg(session, db_user.organization_id, plan)

    if field == "formats":
        await cb.message.edit_text(
            f"📊 <b>{cfg.name}</b> — Formatlar:",
            reply_markup=formats_choice_kb(cfg), parse_mode="HTML")
        await state.update_data(editing_plan=plan_val)
        await cb.answer(); return

    if field == "funcs":
        await cb.message.edit_text(
            f"🛠 <b>{cfg.name}</b> — Funksiyalar:",
            reply_markup=funcs_choice_kb(cfg), parse_mode="HTML")
        await state.update_data(editing_plan=plan_val)
        await cb.answer(); return

    if field == "ai":
        from bot.keyboards import ai_funcs_kb
        await cb.message.edit_text(
            f"🤖 <b>{cfg.name}</b> — Gemini AI funksiyalar:\n\n"
            "ON — yoqilgan | OFF — o'chirilgan",
            reply_markup=ai_funcs_kb(cfg), parse_mode="HTML")
        await state.update_data(editing_plan=plan_val)
        await cb.answer(); return

    if field == "unlimited":
        cfg.unlimited = not cfg.unlimited
        await session.commit()
        await cb.answer(f"{'♾ Cheksiz yoqildi' if cfg.unlimited else '🔢 Limit yoqildi'}")
        await plan_edit(cb, session, db_user); return

    prompts = {"name": "Yangi tarif nomini kiriting:", "desc": "Yangi tavsifni kiriting:",
               "price": "Yangi narxni kiriting (son, so'mda):",
               "limit": "Yangi limitni kiriting (nakladnoy soni/oy):"}
    await state.set_state(AdminPlan.plan_name)
    await state.update_data(editing_plan=plan_val, editing_field=field)
    await cb.message.edit_text(prompts.get(field, "Qiymat kiriting:"))
    await cb.answer()


@router.message(AdminPlan.plan_name)
async def plan_field_save(message: Message, state: FSMContext, session, db_user: User):
    data = await state.get_data()
    plan = SubPlan(data["editing_plan"])
    field = data["editing_field"]
    cfg = await get_plan_cfg(session, db_user.organization_id, plan)
    val = message.text.strip()

    if field == "name":    cfg.name = val
    elif field == "desc":  cfg.description = val
    elif field == "price":
        try: cfg.price = float(val.replace(" ", "").replace(",", "."))
        except: await message.answer("❌ Noto'g'ri son."); return
    elif field == "limit":
        try: cfg.doc_limit = int(val)
        except: await message.answer("❌ Noto'g'ri son."); return

    await log(session, db_user.id, db_user.organization_id, "plan_edit", f"{plan.value}.{field}={val}")
    await session.commit(); await state.clear()
    await message.answer(f"✅ {plan.value} tarifi yangilandi.")


@router.callback_query(F.data.startswith("fmt_tog:"))
async def fmt_toggle(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    action = cb.data.split(":", 1)[1]
    data = await state.get_data()
    if not data.get("editing_plan"): await cb.answer(); return
    plan = SubPlan(data["editing_plan"])
    cfg = await get_plan_cfg(session, db_user.organization_id, plan)
    if action == "excel":  cfg.allow_excel = not cfg.allow_excel
    elif action == "word": cfg.allow_word  = not cfg.allow_word
    elif action == "pdf":  cfg.allow_pdf   = not cfg.allow_pdf
    elif action == "save":
        await session.commit(); await state.clear()
        await cb.message.edit_text("✅ Formatlar saqlandi.", reply_markup=back_to_admin())
        await cb.answer(); return
    await session.commit()
    await cb.message.edit_reply_markup(reply_markup=formats_choice_kb(cfg))
    await cb.answer()


@router.callback_query(F.data.startswith("fn_tog:"))
async def fn_toggle(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    action = cb.data.split(":", 1)[1]
    data = await state.get_data()
    if not data.get("editing_plan"): await cb.answer(); return
    plan = SubPlan(data["editing_plan"])
    cfg = await get_plan_cfg(session, db_user.organization_id, plan)
    if action == "ocr":       cfg.allow_ocr       = not cfg.allow_ocr
    elif action == "report":  cfg.allow_report    = not cfg.allow_report
    elif action == "transport": cfg.allow_transport = not cfg.allow_transport
    elif action == "calc":    cfg.allow_calc      = not cfg.allow_calc
    elif action == "templates":
        cfg.allow_templates = cfg.allow_templates % 10 + 1  # 1..10 davra
    elif action == "save":
        await session.commit(); await state.clear()
        await cb.message.edit_text("✅ Funksiyalar saqlandi.", reply_markup=back_to_admin())
        await cb.answer(); return
    await session.commit()
    await cb.message.edit_reply_markup(reply_markup=funcs_choice_kb(cfg))
    await cb.answer()


# ══════════════ OBUNA ══════════════

@router.callback_query(F.data == "adm:sub")
async def adm_sub(cb: CallbackQuery, state: FSMContext, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    await state.set_state(AdminSub.phone)
    await cb.message.edit_text(
        "💳 <b>Obuna boshqaruvi</b>\n\nXodim telefon raqamini kiriting:",
        parse_mode="HTML"); await cb.answer()


@router.message(AdminSub.phone)
async def sub_phone(message: Message, state: FSMContext, session, db_user: User):
    r = await session.execute(select(User).where(
        User.organization_id == db_user.organization_id, User.phone == message.text.strip()))
    u = r.scalar_one_or_none()
    if not u: await message.answer("Xodim topilmadi."); return
    await state.update_data(target_id=u.id, target_name=u.full_name)
    cfgs = await get_all_cfgs(session, db_user.organization_id)
    await state.set_state(AdminSub.choose_plan)
    await message.answer(f"👤 <b>{u.full_name}</b>\nTarif tanlang:",
                         reply_markup=plans_display_kb(cfgs), parse_mode="HTML")


@router.callback_query(AdminSub.choose_plan, F.data.startswith("plan:"))
async def sub_set(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    plan = SubPlan(cb.data.split(":", 1)[1])
    data = await state.get_data()
    sub = await get_sub(session, db_user.organization_id)
    if sub:
        sub.plan = plan; sub.status = SubStatus.ACTIVE; sub.docs_used = 0
        sub.updated_by = db_user.full_name
    else:
        session.add(Subscription(organization_id=db_user.organization_id, plan=plan,
                                 status=SubStatus.ACTIVE, updated_by=db_user.full_name))
    await log(session, db_user.id, db_user.organization_id, "sub_update",
              f"{data['target_name']}→{plan.value}")
    await session.commit(); await state.clear()
    await cb.message.edit_text(f"✅ <b>{data['target_name']}</b> → <b>{plan.value}</b> tarifi belgilandi.",
                               parse_mode="HTML")
    await cb.answer()


# ══════════════ HISOBOT ══════════════

@router.callback_query(F.data == "adm:report")
@router.message(F.text == "📊 Hisobot")
async def adm_report(event, session, db_user: User):
    msg = event.message if isinstance(event, CallbackQuery) else event
    if db_user.role not in (UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.MANAGER):
        await msg.answer(T.ONLY_MGR, parse_mode="HTML"); return

    import datetime
    now = datetime.datetime.now()
    ms  = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    r = await session.execute(select(func.count()).select_from(Nakladnaya).where(
        Nakladnaya.organization_id == db_user.organization_id, Nakladnaya.created_at >= ms))
    total = r.scalar_one()

    r2 = await session.execute(
        select(Nakladnaya.creator_id, func.count()).where(
            Nakladnaya.organization_id == db_user.organization_id, Nakladnaya.created_at >= ms)
        .group_by(Nakladnaya.creator_id))
    user_stats = r2.all()

    sub = await get_sub(session, db_user.organization_id)
    cfg = await get_plan_cfg(session, db_user.organization_id, sub.plan) if sub else None
    limit = "∞" if (cfg and cfg.unlimited) else (cfg.doc_limit if cfg else "—")

    # Oddiy hisobot
    lines = [
        f"📊 <b>{now.strftime('%B %Y')} — Hisobot</b>\n",
        f"Jami nakladnoy: <b>{total} ta</b>",
        f"Tarif limiti: <b>{limit}</b>\n",
        "Xodimlar bo'yicha:"
    ]
    by_user_text = []
    for uid, cnt in sorted(user_stats, key=lambda x: x[1], reverse=True):
        u = await session.get(User, uid)
        name = u.full_name if u else str(uid)
        lines.append(f"  • {name}: {cnt} ta")
        by_user_text.append({"name": name, "count": cnt})

    text = "\n".join(lines)

    # AI hisobot (agar tarif ruxsat bersa)
    from bot.config import settings as _s
    if cfg and cfg.allow_ai_report and _s.GEMINI_API_KEY:
        text += "\n\n⏳ <i>AI tahlil tayyorlanmoqda...</i>"
        ai_btn = [[__import__('aiogram.types', fromlist=['InlineKeyboardButton']).InlineKeyboardButton(
            text="🤖 AI tahlil olish", callback_data="report:ai"
        )]]
        from aiogram.types import InlineKeyboardMarkup
        kb = InlineKeyboardMarkup(inline_keyboard=ai_btn + back_to_admin().inline_keyboard)
    else:
        kb = back_to_admin()

    if isinstance(event, CallbackQuery):
        await msg.edit_text(text, parse_mode="HTML", reply_markup=kb)
        await event.answer()
    else:
        await msg.answer(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data == "report:ai")
async def report_ai(cb: CallbackQuery, session, db_user: User):
    from bot.config import settings as _s
    if not _s.GEMINI_API_KEY:
        await cb.answer("GEMINI_API_KEY sozlanmagan.", show_alert=True); return

    wait_msg = await cb.message.answer("🤖 AI hisobot tayyorlanmoqda...")
    try:
        import datetime
        now = datetime.datetime.now()
        ms = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        r = await session.execute(select(func.count()).select_from(Nakladnaya).where(
            Nakladnaya.organization_id == db_user.organization_id, Nakladnaya.created_at >= ms))
        total = r.scalar_one()

        r2 = await session.execute(
            select(Nakladnaya.creator_id, func.count()).where(
                Nakladnaya.organization_id == db_user.organization_id, Nakladnaya.created_at >= ms)
            .group_by(Nakladnaya.creator_id))

        by_user = []
        for uid, cnt in r2.all():
            u = await session.get(User, uid)
            by_user.append({"xodim": u.full_name if u else str(uid), "nakladnoylar": cnt})

        stats = {
            "oy": now.strftime("%B %Y"),
            "jami_nakladnoy": total,
            "xodimlar": by_user,
        }

        from bot.services.gemini_service import ai_generate_report
        ai_text = await ai_generate_report(stats)
        await wait_msg.delete()
        await cb.message.answer(
            f"🤖 <b>AI Tahliliy hisobot:</b>\n\n{ai_text}",
            parse_mode="HTML", reply_markup=back_to_admin()
        )
    except Exception as e:
        await wait_msg.delete()
        await cb.message.answer(f"❌ AI xato: {e}")
    await cb.answer()


# ══════════════ AUDIT ══════════════

@router.callback_query(F.data == "adm:audit")
async def adm_audit(cb: CallbackQuery, session, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    r = await session.execute(
        select(AuditLog).where(AuditLog.org_id == db_user.organization_id)
        .order_by(AuditLog.created_at.desc()).limit(20))
    logs = r.scalars().all()
    if not logs:
        await cb.message.edit_text("Jurnal bo'sh.", reply_markup=back_to_admin()); await cb.answer(); return
    lines = ["📒 <b>Audit jurnali (so'nggi 20):</b>\n"]
    for l in logs:
        d  = l.created_at.strftime("%d.%m %H:%M") if l.created_at else ""
        ic = "⚠️" if l.suspicious else "▪"
        lines.append(f"{ic} <code>{d}</code> | {l.action} | {l.detail[:40]}")
    await cb.message.edit_text("\n".join(lines), parse_mode="HTML", reply_markup=back_to_admin())
    await cb.answer()


@router.callback_query(F.data == "adm:suspicious")
async def adm_suspicious(cb: CallbackQuery, session, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    r = await session.execute(
        select(AuditLog).where(AuditLog.org_id == db_user.organization_id, AuditLog.suspicious == True)
        .order_by(AuditLog.created_at.desc()).limit(20))
    logs = r.scalars().all()
    if not logs:
        await cb.message.edit_text("⚠️ Shubhali harakatlar topilmadi.", reply_markup=back_to_admin())
        await cb.answer(); return
    lines = ["⚠️ <b>Shubhali harakatlar:</b>\n"]
    for l in logs:
        u = await session.get(User, l.user_id) if l.user_id else None
        d = l.created_at.strftime("%d.%m %H:%M") if l.created_at else ""
        lines.append(f"⚠️ <code>{d}</code> | {u.full_name if u else '?'}\n   {l.detail}\n")
    await cb.message.edit_text("\n".join(lines), parse_mode="HTML", reply_markup=back_to_admin())
    await cb.answer()


# ══════════════ TASHKILOT SOZLAMALARI ══════════════

@router.callback_query(F.data == "adm:org")
async def adm_org(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    if not _adm(db_user): await cb.answer(); return
    org = await session.get(Organization, db_user.organization_id)
    await state.set_state(AdminObj.text)
    await cb.message.edit_text(
        f"🏗 <b>Tashkilot sozlamalari</b>\n\n"
        f"Nomi: {org.name if org else '—'}\n"
        f"Standart obyekt: {org.object_text if org else '—'}\n\n"
        "Yangi standart obyekt matnini kiriting (yoki '.' qoldirish uchun):",
        parse_mode="HTML"); await cb.answer()


@router.message(AdminObj.text)
async def org_obj_save(message: Message, state: FSMContext, session, db_user: User):
    if message.text.strip() != ".":
        org = await session.get(Organization, db_user.organization_id)
        if org: org.object_text = message.text.strip()
        await session.commit()
        await message.answer("✅ Standart obyekt matni saqlandi.")
    await state.clear()


@router.callback_query(F.data.startswith("ai_tog:"))
async def ai_toggle(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    action = cb.data.split(":", 1)[1]
    data = await state.get_data()
    if not data.get("editing_plan"): await cb.answer(); return
    plan = SubPlan(data["editing_plan"])
    cfg = await get_plan_cfg(session, db_user.organization_id, plan)

    if action == "ai_calc":       cfg.allow_ai_calc      = not cfg.allow_ai_calc
    elif action == "ai_chat":     cfg.allow_ai_chat      = not cfg.allow_ai_chat
    elif action == "ai_search":   cfg.allow_ai_search    = not cfg.allow_ai_search
    elif action == "ai_report":   cfg.allow_ai_report    = not cfg.allow_ai_report
    elif action == "ai_anomaly":  cfg.allow_ai_anomaly   = not cfg.allow_ai_anomaly
    elif action == "ai_briefing": cfg.allow_ai_briefing  = not cfg.allow_ai_briefing
    elif action == "ai_voice":    cfg.allow_ai_voice     = not cfg.allow_ai_voice
    elif action == "ai_translate":cfg.allow_ai_translate = not cfg.allow_ai_translate
    elif action == "save":
        await session.commit(); await state.clear()
        await cb.message.edit_text("AI funksiyalar saqlandi.", reply_markup=back_to_admin())
        await cb.answer(); return
    await session.commit()
    await cb.message.edit_reply_markup(reply_markup=ai_funcs_kb(cfg))
    await cb.answer()
