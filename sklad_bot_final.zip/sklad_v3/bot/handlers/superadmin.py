from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import select
from bot.config import settings
from bot.models import AllowedPhone, Organization, Subscription, SubPlan, SubStatus, UserRole
from bot.services.subscription import ensure_default_plans

router = Router(name="superadmin")


def _sa(m: Message) -> bool:
    return m.from_user.id == settings.SUPER_ADMIN_ID


@router.message(Command("neworg"))
async def new_org(message: Message, session):
    if not _sa(message): return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2: await message.answer('/neworg "Nomi"'); return
    org = Organization(name=parts[1].strip())
    session.add(org); await session.flush()
    session.add(Subscription(organization_id=org.id, plan=SubPlan.BASIC, status=SubStatus.TRIAL))
    await ensure_default_plans(session, org.id)
    await session.commit()
    await message.answer(f"✅ Tashkilot yaratildi.\nID: <b>{org.id}</b>\nNomi: <b>{org.name}</b>", parse_mode="HTML")


@router.message(Command("newadmin"))
async def new_admin(message: Message, session):
    if not _sa(message): return
    parts = message.text.split(maxsplit=3)
    if len(parts) != 4: await message.answer("/newadmin <org_id> <tel> <F.I.Sh>"); return
    _, org_id, phone, name = parts
    org = await session.get(Organization, int(org_id))
    if not org: await message.answer("Tashkilot topilmadi."); return
    r = await session.execute(select(AllowedPhone).where(AllowedPhone.phone_number == phone))
    if r.scalar_one_or_none(): await message.answer("Bu raqam mavjud."); return
    session.add(AllowedPhone(organization_id=org.id, phone_number=phone,
                             full_name=name, role=UserRole.ADMIN))
    await session.commit()
    await message.answer(f"✅ <b>{name}</b> ({phone}) → <b>{org.name}</b>ga admin qo'shildi.", parse_mode="HTML")


@router.message(Command("orglist"))
async def org_list(message: Message, session):
    if not _sa(message): return
    r = await session.execute(select(Organization))
    orgs = r.scalars().all()
    if not orgs: await message.answer("Tashkilotlar yo'q."); return
    await message.answer("\n".join(f"#{o.id} — {o.name}" for o in orgs))
