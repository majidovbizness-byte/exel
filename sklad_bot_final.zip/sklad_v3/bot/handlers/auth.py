"""Ro'yxatdan o'tish va kirish."""
import re
from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select

from bot import texts as T
from bot.keyboards import contact_kb, main_menu, plans_display_kb, rm
from bot.models import AllowedPhone, SubStatus, Subscription, User
from bot.services.audit import log
from bot.services.subscription import ensure_default_plans, get_all_cfgs, get_sub
from bot.states import Reg

router = Router(name="auth")


def _norm(phone: str) -> str:
    d = re.sub(r"\D", "", phone)
    return d[-9:] if len(d) >= 9 else d


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, session, db_user: User | None):
    if db_user and db_user.is_active and db_user.pw_hash:
        cfg = None
        sub = await get_sub(session, db_user.organization_id)
        if sub:
            from bot.services.subscription import get_plan_cfg
            cfg = await get_plan_cfg(session, db_user.organization_id, sub.plan)
        has_ocr = cfg.allow_ocr if cfg else False
        await message.answer(T.MAIN_MENU, reply_markup=main_menu(db_user.role, has_ocr), parse_mode="HTML")
        return

    await state.clear()
    await state.set_state(Reg.phone)
    await message.answer(T.WELCOME, parse_mode="HTML")
    await message.answer(T.ASK_PHONE, reply_markup=contact_kb(), parse_mode="HTML")


@router.message(Reg.phone, F.contact)
async def got_phone(message: Message, state: FSMContext, session):
    c = message.contact
    if c.user_id and c.user_id != message.from_user.id:
        await message.answer("⚠️ Faqat o'zingizning kontaktingizni yuboring.", reply_markup=contact_kb())
        return

    phone_norm = _norm(c.phone_number)
    r = await session.execute(select(AllowedPhone))
    matched = next((a for a in r.scalars() if _norm(a.phone_number) == phone_norm), None)

    if not matched:
        await message.answer(T.NOT_ALLOWED, reply_markup=rm(), parse_mode="HTML")
        await state.clear(); return

    await state.update_data(phone=c.phone_number, org_id=matched.organization_id,
                            role=matched.role.value, position=matched.position)
    await state.set_state(Reg.full_name)
    await message.answer(T.ASK_NAME, reply_markup=rm(), parse_mode="HTML")


@router.message(Reg.phone)
async def phone_bad(message: Message):
    await message.answer(T.ASK_PHONE, reply_markup=contact_kb(), parse_mode="HTML")


@router.message(Reg.full_name)
async def got_name(message: Message, state: FSMContext):
    name = message.text.strip()
    if len(name) < 3:
        await message.answer("❌ Kamida 3 ta belgi kiriting."); return
    await state.update_data(full_name=name)
    await state.set_state(Reg.password)
    await message.answer(T.ASK_PW, parse_mode="HTML")


@router.message(Reg.password)
async def got_pw(message: Message, state: FSMContext):
    pw = message.text.strip()
    await message.delete()
    if len(pw) < 6:
        await message.answer(T.PW_SHORT, parse_mode="HTML"); return
    await state.update_data(pw=pw)
    await state.set_state(Reg.confirm_pw)
    await message.answer(T.ASK_PW2, parse_mode="HTML")


@router.message(Reg.confirm_pw)
async def confirm_pw(message: Message, state: FSMContext, session):
    pw2 = message.text.strip()
    await message.delete()
    data = await state.get_data()
    if pw2 != data["pw"]:
        await message.answer(T.PW_MISMATCH, parse_mode="HTML"); return

    tg = message.from_user
    uname = User.gen_username(data["full_name"], tg.id)
    r = await session.execute(select(User).where(User.username == uname))
    if r.scalar_one_or_none():
        uname = f"{uname}_{tg.id % 999}"

    user = User(telegram_id=tg.id, phone=data["phone"], full_name=data["full_name"],
                username=uname, role=data["role"], organization_id=data["org_id"],
                position=data.get("position", ""), is_active=True)
    user.set_pw(data["pw"])
    session.add(user); await session.flush()
    await log(session, user.id, data["org_id"], "register", uname)

    # Standart obuna yaratish
    sub = await get_sub(session, data["org_id"])
    if not sub:
        from bot.models import SubPlan
        session.add(Subscription(organization_id=data["org_id"],
                                 plan=SubPlan.BASIC, status=SubStatus.TRIAL))
    await ensure_default_plans(session, data["org_id"])
    await session.commit()
    await state.clear()

    await message.answer(T.REG_OK.format(name=data["full_name"], username=uname, phone=data["phone"]),
                         parse_mode="HTML")

    # Tarif tanlash
    cfgs = await get_all_cfgs(session, data["org_id"])
    if cfgs:
        await message.answer(T.PLAN_CHOOSE, reply_markup=plans_display_kb(cfgs), parse_mode="HTML")


@router.callback_query(F.data.startswith("plan:"))
async def plan_chosen(cb: CallbackQuery, session, db_user: User):
    if not db_user: await cb.answer(); return
    from bot.models import SubPlan
    plan = SubPlan(cb.data.split(":", 1)[1])
    sub = await get_sub(session, db_user.organization_id)
    if sub:
        sub.plan = plan; sub.status = SubStatus.TRIAL; sub.docs_used = 0
    from bot.services.subscription import get_plan_cfg
    cfg = await get_plan_cfg(session, db_user.organization_id, plan)
    await session.commit()

    has_ocr = cfg.allow_ocr if cfg else False
    plan_name = cfg.name if cfg else plan.value
    await cb.message.edit_text(
        f"✅ <b>{plan_name}</b> tarifi tanlandi!\n\n"
        "Administrator tarifni faollashtirgandan so'ng to'liq foydalanishingiz mumkin.\n"
        "Hozircha sinov rejimida ishlayapsiz.",
        parse_mode="HTML"
    )
    await cb.message.answer(T.MAIN_MENU, reply_markup=main_menu(db_user.role, has_ocr), parse_mode="HTML")
    await cb.answer()
