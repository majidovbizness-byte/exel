from aiogram import Router
from bot.handlers import auth, menu, nakladnaya, ocr, calculator, receive, admin, superadmin


def get_router() -> Router:
    root = Router(name="root")
    root.include_router(auth.router)
    root.include_router(superadmin.router)
    root.include_router(receive.router)
    root.include_router(nakladnaya.router)
    root.include_router(ocr.router)
    root.include_router(calculator.router)
    root.include_router(admin.router)
    root.include_router(menu.router)
    return root
