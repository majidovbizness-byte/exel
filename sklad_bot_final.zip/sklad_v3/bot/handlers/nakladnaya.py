"""Nakladnoy yaratish — to'liq FSM."""
import random
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, FSInputFile, Message
from sqlalchemy import select

from bot import texts as T
from bot.keyboards import (confirm_kb, doc_type_kb, format_kb, main_menu,
                           more_items_kb, nakladnoy_view_kb, search_results_kb,
                           skip_or_blank_kb, template_kb, units_kb)
from bot.models import (Nakladnaya, NakItem, Organization, User, Vehicle)
from bot.services import materials as mat_svc
from bot.services.audit import log, check_suspicious
from bot.services.documents.generate import generate
from bot.services.documents.preview import build_preview
from bot.services.numbering import next_number
from bot.services.subscription import current_cfg, get_sub
from bot.states import Nak

router = Router(name="nakladnaya")

BLANK = "________________________"  # Bo'sh maydon uchun yozma shakl


def _blank_or(text: str) -> str:
    """Agar foydalanuvchi '___' yoki BLANK yuborganida bo'sh qoladi."""
    if not text or set(text.strip()).issubset({"_", " ", "-"}):
        return BLANK
    return text.strip()


@router.message(F.text == "🆕 Yangi nakladnoy")
async def nak_start(message: Message, state: FSMContext, session, db_user: User):
    if not db_user or not db_user.organization_id:
        await message.answer("Tizimga kirish kerak. /start yuboring."); return

    sub = await get_sub(session, db_user.organization_id)
    cfg = await current_cfg(session, db_user.organization_id)
    if sub and cfg:
        ok, reason = sub.can_create(cfg)
        if not ok:
            if reason == "expired":
                await message.answer(T.PLAN_EXPIRED_MSG, parse_mode="HTML"); return
            elif reason.startswith("limit:"):
                _, counts = reason.split(":", 1)
                used, limit = counts.split("/")
                await message.answer(T.PLAN_LIMIT_MSG.format(used=used, limit=limit), parse_mode="HTML"); return

    await state.clear()
    await state.update_data(items=[])
    await state.set_state(Nak.doc_type)
    await message.answer(T.NAK_START, reply_markup=doc_type_kb(), parse_mode="HTML")


@router.callback_query(Nak.doc_type, F.data.startswith("dt:"))
async def nak_doctype(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    await state.update_data(doc_type=cb.data.split(":", 1)[1])
    org = await session.get(Organization, db_user.organization_id)
    prev = org.object_text if org else "—"
    await state.set_state(Nak.obj)
    await cb.message.edit_text(T.NAK_OBJ.format(prev=prev), parse_mode="HTML")
    await cb.answer()


@router.message(Nak.obj)
async def nak_obj(message: Message, state: FSMContext, session, db_user: User):
    txt = message.text.strip()
    if txt == ".":
        org = await session.get(Organization, db_user.organization_id)
        txt = org.object_text if org else BLANK
    await state.update_data(obj=_blank_or(txt))
    await state.set_state(Nak.sender)
    await message.answer(T.NAK_SENDER, parse_mode="HTML")


@router.message(Nak.sender)
async def nak_sender(message: Message, state: FSMContext):
    await state.update_data(sender=_blank_or(message.text.strip()))
    await state.set_state(Nak.receiver)
    await message.answer(T.NAK_RECEIVER, parse_mode="HTML")


@router.message(Nak.receiver)
async def nak_receiver(message: Message, state: FSMContext):
    await state.update_data(receiver=_blank_or(message.text.strip()))
    await state.set_state(Nak.vehicle)
    await message.answer(T.NAK_VEHICLE, reply_markup=skip_or_blank_kb("veh"), parse_mode="HTML")


@router.callback_query(Nak.vehicle, F.data.in_({"skip", "veh", "veh_blank"}))
async def nak_veh_skip(cb: CallbackQuery, state: FSMContext):
    blank = cb.data == "veh_blank"
    await state.update_data(veh_plate=BLANK if blank else "",
                            veh_model=BLANK if blank else "", driver=BLANK if blank else "")
    await state.set_state(Nak.destination)
    await cb.message.edit_text(T.NAK_DEST, parse_mode="HTML")
    await cb.answer()


@router.message(Nak.vehicle)
async def nak_vehicle(message: Message, state: FSMContext, session, db_user: User):
    plate = message.text.strip()
    await state.update_data(veh_plate=plate)
    r = await session.execute(select(Vehicle).where(
        Vehicle.organization_id == db_user.organization_id, Vehicle.plate == plate))
    veh = r.scalar_one_or_none()
    if veh:
        await state.update_data(veh_model=veh.model, driver=veh.driver)
        await state.set_state(Nak.destination)
        await message.answer(T.NAK_VEH_FOUND.format(model=veh.model, driver=veh.driver), parse_mode="HTML")
        await message.answer(T.NAK_DEST, reply_markup=skip_or_blank_kb("dest"), parse_mode="HTML")
    else:
        await state.set_state(Nak.veh_model)
        await message.answer(T.NAK_VEH_MODEL, reply_markup=skip_or_blank_kb("vmodel"), parse_mode="HTML")


@router.callback_query(Nak.veh_model, F.data.in_({"vmodel", "vmodel_blank"}))
async def nak_vmodel_skip(cb: CallbackQuery, state: FSMContext):
    blank = cb.data == "vmodel_blank"
    await state.update_data(veh_model=BLANK if blank else "")
    await state.set_state(Nak.driver)
    await cb.message.edit_text(T.NAK_DRIVER, parse_mode="HTML")
    await cb.answer()


@router.message(Nak.veh_model)
async def nak_veh_model(message: Message, state: FSMContext):
    await state.update_data(veh_model=_blank_or(message.text.strip()))
    await state.set_state(Nak.driver)
    await message.answer(T.NAK_DRIVER, reply_markup=skip_or_blank_kb("drv"), parse_mode="HTML")


@router.callback_query(Nak.driver, F.data.in_({"drv", "drv_blank"}))
async def nak_drv_skip(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    blank = cb.data == "drv_blank"
    await state.update_data(driver=BLANK if blank else "")
    await _save_vehicle(state, session, db_user)
    await state.set_state(Nak.destination)
    await cb.message.edit_text(T.NAK_DEST, reply_markup=skip_or_blank_kb("dest"), parse_mode="HTML")
    await cb.answer()


@router.message(Nak.driver)
async def nak_driver(message: Message, state: FSMContext, session, db_user: User):
    await state.update_data(driver=_blank_or(message.text.strip()))
    await _save_vehicle(state, session, db_user)
    await state.set_state(Nak.destination)
    await message.answer(T.NAK_DEST, reply_markup=skip_or_blank_kb("dest"), parse_mode="HTML")


async def _save_vehicle(state: FSMContext, session, db_user: User):
    data = await state.get_data()
    plate = data.get("veh_plate", "")
    if plate and plate != BLANK:
        r = await session.execute(select(Vehicle).where(
            Vehicle.organization_id == db_user.organization_id, Vehicle.plate == plate))
        if not r.scalar_one_or_none():
            session.add(Vehicle(organization_id=db_user.organization_id,
                                plate=plate, model=data.get("veh_model", ""),
                                driver=data.get("driver", "")))
            await session.commit()


@router.callback_query(Nak.destination, F.data.in_({"dest", "dest_blank"}))
async def nak_dest_skip(cb: CallbackQuery, state: FSMContext):
    blank = cb.data == "dest_blank"
    await state.update_data(dest=BLANK if blank else "")
    await _ask_item(cb.message, state)
    await cb.answer()


@router.message(Nak.destination)
async def nak_dest(message: Message, state: FSMContext):
    await state.update_data(dest=_blank_or(message.text.strip()))
    await _ask_item(message, state)


# ── Mahsulot davri ──────────────────────────────────────────────────

async def _ask_item(message: Message, state: FSMContext):
    data = await state.get_data()
    count = len(data.get("items", []))
    await state.set_state(Nak.item)
    await message.answer(T.NAK_ITEM_PROMPT.format(count=count), parse_mode="HTML")


@router.message(Nak.item)
async def nak_item(message: Message, state: FSMContext, session, db_user: User):
    txt = message.text.strip()
    if txt.replace(" ", "").isdigit():
        m = await mat_svc.by_code(session, db_user.organization_id, txt)
        if m:
            await state.update_data(p_code=m.code, p_name=m.name, p_unit=m.unit)
            await state.set_state(Nak.item_qty)
            await message.answer(T.NAK_FOUND.format(name=m.name, unit=m.unit), parse_mode="HTML")
            return
    results = await mat_svc.search(session, db_user.organization_id, txt)

    # Oddiy qidiruv topsa — ko'rsatamiz
    if results:
        await state.set_state(Nak.item_search)
        await message.answer(
            f"🔍 <b>«{txt}» bo'yicha natijalar:</b>",
            reply_markup=search_results_kb(results), parse_mode="HTML"
        )
        return

    # Oddiy qidiruv topmasa — AI qidiruv ishlatamiz (agar tarif ruxsat bersa)
    from bot.config import settings as _s
    cfg = await current_cfg(session, db_user.organization_id)
    if cfg and cfg.allow_ai_search and _s.GEMINI_API_KEY:
        wait_msg = await message.answer("🤖 AI qidiryapti...")
        try:
            from bot.services.gemini_service import ai_search_material
            from sqlalchemy import select as _sel
            from bot.models import Material as _Mat
            r = await session.execute(_sel(_Mat).where(_Mat.organization_id == db_user.organization_id).limit(200))
            all_mats = [{"code": m.code, "name": m.name, "unit": m.unit} for m in r.scalars()]
            ai_results_raw = await ai_search_material(txt, all_mats)
            await wait_msg.delete()
            if ai_results_raw:
                # AI topdi — fakelar bilan search_results_kb uchun Material ob'ektlari
                ai_mats = []
                for mr in ai_results_raw:
                    m = await mat_svc.by_code(session, db_user.organization_id, mr.get("code",""))
                    if m:
                        ai_mats.append(m)
                if ai_mats:
                    await state.set_state(Nak.item_search)
                    await message.answer(
                        f"🤖 <b>AI topdi «{txt}» uchun:</b>",
                        reply_markup=search_results_kb(ai_mats), parse_mode="HTML"
                    )
                    return
        except Exception:
            try: await wait_msg.delete()
            except: pass

    # Hech narsa topilmadi — qo'lda kiritish
    await state.update_data(p_code="", p_name=txt)
    await state.set_state(Nak.item_unit)
    await message.answer(T.NAK_NOT_FOUND.format(q=txt), reply_markup=units_kb(), parse_mode="HTML")


@router.callback_query(Nak.item_search, F.data.startswith("mat:"))
async def nak_pick(cb: CallbackQuery, state: FSMContext, session):
    val = cb.data.split(":", 1)[1]
    if val == "manual":
        await state.set_state(Nak.item)
        await cb.message.edit_text(T.NAK_ITEM_PROMPT.format(count=0), parse_mode="HTML")
        await cb.answer(); return
    m = await mat_svc.get(session, int(val))
    if not m: await cb.answer("Topilmadi.", show_alert=True); return
    await state.update_data(p_code=m.code, p_name=m.name, p_unit=m.unit)
    await state.set_state(Nak.item_qty)
    await cb.message.edit_text(T.NAK_FOUND.format(name=m.name, unit=m.unit), parse_mode="HTML")
    await cb.answer()


@router.callback_query(Nak.item_unit, F.data.startswith("unit:"))
async def nak_unit(cb: CallbackQuery, state: FSMContext):
    unit = cb.data.split(":", 1)[1]
    await state.update_data(p_unit=unit)
    await state.set_state(Nak.item_qty)
    await cb.message.edit_text(T.NAK_QTY, parse_mode="HTML")
    await cb.answer()


@router.message(Nak.item_qty)
async def nak_qty(message: Message, state: FSMContext):
    qty = message.text.strip()
    data = await state.get_data()
    items = data.get("items", [])
    items.append({"code": data.get("p_code", ""), "name": data.get("p_name", ""),
                  "unit": data.get("p_unit", ""), "qty": qty})
    await state.update_data(items=items)
    await state.set_state(Nak.more)
    summary = "\n".join(f"  {i+1}. {it['name']} — {it['qty']} {it['unit']}" for i, it in enumerate(items))
    await message.answer(
        T.NAK_ADDED.format(name=data.get("p_name",""), qty=qty, unit=data.get("p_unit",""))
        + f"\n\n📋 <b>Ro'yxat:</b>\n{summary}",
        reply_markup=more_items_kb(len(items)), parse_mode="HTML"
    )


@router.callback_query(Nak.more, F.data == "more:yes")
async def nak_more(cb: CallbackQuery, state: FSMContext):
    await _ask_item(cb.message, state); await cb.answer()


@router.callback_query(Nak.more, F.data == "more:no")
async def nak_done_items(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    data = await state.get_data()
    if not data.get("items"):
        await cb.answer("Kamida 1 ta mahsulot qo'shing!", show_alert=True); return
    cfg = await current_cfg(session, db_user.organization_id)
    max_tpl = cfg.allow_templates if cfg else 2

    # AI shablon tavsiyasi
    from bot.config import settings as _s
    suggested_tpl = 1
    suggestion_text = ""
    if cfg and cfg.allow_ai_search and _s.GEMINI_API_KEY:
        try:
            from bot.services.gemini_service import ai_suggest_template
            suggested_tpl = await ai_suggest_template(data.get("items", []))
            from bot.keyboards import TEMPLATES_NAMES
            tpl_name = TEMPLATES_NAMES.get(suggested_tpl, "Klassik")
            suggestion_text = f"\n\n🤖 <i>AI tavsiya: {tpl_name} (#{suggested_tpl})</i>"
        except Exception:
            pass

    await state.update_data(suggested_tpl=suggested_tpl)
    await state.set_state(Nak.template)
    await cb.message.edit_text(
        f"📋 <b>Shablonni tanlang:</b>{suggestion_text}",
        reply_markup=template_kb(max_tpl), parse_mode="HTML"
    )
    await cb.answer()


@router.callback_query(Nak.template, F.data.startswith("tpl:"))
async def nak_template(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    tpl = int(cb.data.split(":", 1)[1])
    await state.update_data(tpl=tpl)
    cfg = await current_cfg(session, db_user.organization_id)
    await state.set_state(Nak.fmt)
    await cb.message.edit_text("📄 <b>Fayl formatini tanlang:</b>",
                               reply_markup=format_kb(cfg), parse_mode="HTML")
    await cb.answer()


@router.callback_query(Nak.fmt, F.data.startswith("fmt:"))
async def nak_fmt(cb: CallbackQuery, state: FSMContext):
    await state.update_data(fmt=cb.data.split(":", 1)[1])
    data = await state.get_data()
    items_text = "\n".join(
        f"  {i+1}. {it['name']} — {it['qty']} {it['unit']}"
        for i, it in enumerate(data["items"])
    )
    veh = f"{data.get('veh_model','')} {data.get('veh_plate','')}".strip() or BLANK
    await state.set_state(Nak.confirm)
    await cb.message.edit_text(
        T.NAK_CONFIRM.format(
            dtype="Chiqim" if data["doc_type"] == "chiqim" else "Qaytarish",
            obj=data.get("obj", BLANK), sender=data.get("sender", BLANK),
            receiver=data.get("receiver", BLANK), veh=veh,
            driver=data.get("driver", BLANK), dest=data.get("dest", BLANK),
            count=len(data["items"]), items=items_text,
        ),
        reply_markup=confirm_kb(), parse_mode="HTML"
    )
    await cb.answer()


@router.callback_query(Nak.confirm, F.data == "confirm:edit")
async def nak_edit(cb: CallbackQuery, state: FSMContext, db_user: User):
    """Orqaga qaytish — hujjat turidan qaytadan boshlash."""
    await cb.message.edit_text("✏️ Qaytadan boshlash...")
    await state.set_state(Nak.doc_type)
    await cb.message.answer(T.NAK_START, reply_markup=doc_type_kb(), parse_mode="HTML")
    await cb.answer()


@router.callback_query(Nak.confirm, F.data == "confirm:no")
async def nak_cancel(cb: CallbackQuery, state: FSMContext, db_user: User):
    await state.clear()
    await cb.message.edit_text("❌ Bekor qilindi.")
    await cb.message.answer(T.MAIN_MENU, reply_markup=main_menu(db_user.role), parse_mode="HTML")
    await cb.answer()


@router.callback_query(Nak.confirm, F.data == "confirm:yes")
async def nak_create(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    data = await state.get_data()
    org = await session.get(Organization, db_user.organization_id)
    sub = await get_sub(session, db_user.organization_id)
    cfg = await current_cfg(session, db_user.organization_id)

    if sub and cfg:
        ok, reason = sub.can_create(cfg)
        if not ok:
            await cb.message.edit_text(T.PLAN_EXPIRED_MSG if reason == "expired" else T.PLAN_LIMIT_MSG.format(used=0, limit=0), parse_mode="HTML")
            await cb.answer(); return

    number = await next_number(session, db_user.organization_id)
    pin    = f"{random.randint(0, 9999):04d}"

    nak = Nakladnaya(
        number=number, organization_id=db_user.organization_id,
        creator_id=db_user.id, doc_type=data["doc_type"],
        object_text=data.get("obj", ""), sender=data.get("sender", ""),
        receiver=data.get("receiver", ""), vehicle_plate=data.get("veh_plate", ""),
        vehicle_model=data.get("veh_model", ""), driver=data.get("driver", ""),
        destination=data.get("dest", ""), template_id=data.get("tpl", 1),
        pin=pin, source="manual",
    )
    for i, it in enumerate(data["items"], 1):
        nak.items.append(NakItem(row_no=i, code=it["code"], name=it["name"],
                                 unit=it["unit"], quantity=it["qty"]))
    session.add(nak)
    await session.flush()
    if sub: sub.docs_used += 1

    # Shubhali harakatlar tekshiruvi
    warnings = await check_suspicious(session, db_user.id, db_user.organization_id)
    for w in warnings:
        await log(session, db_user.id, db_user.organization_id, "suspicious", w, suspicious=True)

    # Gemini AI anomaliya tekshiruvi (agar tarif ruxsat bersa)
    from bot.config import settings as _s
    if cfg and cfg.allow_ai_anomaly and _s.GEMINI_API_KEY:
        try:
            from bot.models import AuditLog as _AL
            from sqlalchemy import select as _sel
            r_log = await session.execute(
                _sel(_AL).where(_AL.user_id == db_user.id).order_by(_AL.created_at.desc()).limit(20))
            actions = [
                {"action": l.action, "detail": l.detail,
                 "time": l.created_at.strftime("%H:%M") if l.created_at else ""}
                for l in r_log.scalars()
            ]
            from bot.services.gemini_service import ai_check_anomaly
            anomaly = await ai_check_anomaly(db_user.full_name, actions)
            if anomaly:
                await log(session, db_user.id, db_user.organization_id,
                         "ai_anomaly", anomaly, suspicious=True)
                # Admin(lar)ga xabar yuborish
                from bot.models import User as _U, UserRole as _UR
                admins_r = await session.execute(
                    _sel(_U).where(
                        _U.organization_id == db_user.organization_id,
                        _U.is_active == True))
                for adm in admins_r.scalars():
                    if adm.role.value not in ("admin", "super_admin"): continue
                    try:
                        await cb.bot.send_message(
                            adm.telegram_id,
                            f"AI anomaliya: {db_user.full_name}\n{anomaly}",
                            parse_mode="HTML"
                        )
                    except Exception:
                        pass
        except Exception:
            pass

    await log(session, db_user.id, db_user.organization_id, "nak_create", number)
    await session.commit()

    import datetime
    nak.created_at = datetime.datetime.now()
    await cb.message.edit_text(f"⏳ <b>№{number}</b> tayyorlanmoqda...", parse_mode="HTML")

    # Fayl yaratish
    try:
        path = await generate(nak, org.name if org else "", data.get("fmt", "excel"), cfg, data.get("tpl", 1))
        await cb.message.answer_document(
            FSInputFile(path),
            caption=T.NAK_DONE.format(number=number, pin=pin), parse_mode="HTML"
        )
        # Preview rasm
        preview_bytes = build_preview(nak, org.name if org else "")
        from aiogram.types import BufferedInputFile
        await cb.message.answer_photo(
            BufferedInputFile(preview_bytes, filename=f"nak_{number.replace('/', '-')}.png"),
            caption=f"🖼 <b>№{number} ko'rinishi</b>",
            parse_mode="HTML"
        )
        # Ko'rish tugmalari
        await cb.message.answer(
            "📋 Nakladnoy bilan nima qilmoqchisiz?",
            reply_markup=nakladnoy_view_kb(
                nak.id,
                cfg.allow_excel if cfg else True,
                cfg.allow_word if cfg else False,
                cfg.allow_pdf if cfg else False,
            )
        )
    except Exception as e:
        await cb.message.answer(f"⚠️ Fayl yaratishda xato: {e}")

    await state.clear()
    cfg2 = await current_cfg(session, db_user.organization_id)
    has_ocr = cfg2.allow_ocr if cfg2 else False
    await cb.message.answer(T.MAIN_MENU, reply_markup=main_menu(db_user.role, has_ocr), parse_mode="HTML")
    await cb.answer()


# ── Ko'rish tugmalari ────────────────────────────────────────────────

@router.callback_query(F.data.startswith("view:"))
async def view_action(cb: CallbackQuery, session, db_user: User):
    parts = cb.data.split(":")
    action = parts[1]
    nak_id = int(parts[2])

    nak = await session.get(Nakladnaya, nak_id)
    if not nak or nak.organization_id != db_user.organization_id:
        await cb.answer("Topilmadi.", show_alert=True); return

    org = await session.get(Organization, nak.organization_id)
    cfg = await current_cfg(session, db_user.organization_id)
    org_name = org.name if org else ""

    if action == "preview":
        preview_bytes = build_preview(nak, org_name)
        from aiogram.types import BufferedInputFile
        await cb.message.answer_photo(
            BufferedInputFile(preview_bytes, filename=f"preview_{nak_id}.png"),
            caption=f"🖼 <b>№{nak.number} ko'rinishi</b>", parse_mode="HTML"
        )
    elif action in ("excel", "word", "pdf"):
        path = await generate(nak, org_name, action, cfg, nak.template_id)
        await cb.message.answer_document(FSInputFile(path))
    elif action == "del":
        await session.delete(nak)
        await session.commit()
        await cb.message.edit_text("🗑 Nakladnoy o'chirildi.")

    await cb.answer()
