"""Sozlamalar, tarix, parol o'zgartirish."""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select

from bot import texts as T
from bot.keyboards import main_menu, nakladnoy_view_kb, pw_change_kb
from bot.models import Nakladnaya, Organization, User
from bot.services.documents.preview import build_preview
from bot.services.subscription import current_cfg, get_sub
from bot.states import PwChange

router = Router(name="menu")

ROLES = {"super_admin": "Bosh administrator", "admin": "Administrator",
         "manager": "Rahbar", "employee": "Xodim"}
STATUS = {"active": "✅ Faol", "trial": "🔸 Sinov", "expired": "❌ Tugagan"}


@router.message(F.text == "⚙️ Sozlamalar")
async def settings(message: Message, session, db_user: User):
    sub = await get_sub(session, db_user.organization_id)
    cfg = await current_cfg(session, db_user.organization_id)

    plan  = cfg.name if cfg else "—"
    status= STATUS.get(sub.status.value if sub else "", "—")
    used  = sub.docs_used if sub else 0
    limit = "∞" if (cfg and cfg.unlimited) else (cfg.doc_limit if cfg else "—")
    seen  = db_user.last_seen.strftime("%d.%m.%Y %H:%M") if db_user.last_seen else "—"

    await message.answer(
        T.SETTINGS.format(
            name=db_user.full_name, uname=db_user.username,
            phone=db_user.phone, pos=db_user.position or "—",
            role=ROLES.get(db_user.role.value, db_user.role.value),
            plan=plan, status=status, used=used, limit=limit, seen=seen,
        ),
        reply_markup=pw_change_kb(), parse_mode="HTML"
    )


@router.callback_query(F.data == "pw:change")
async def pw_start(cb: CallbackQuery, state: FSMContext):
    await state.set_state(PwChange.old_pw)
    await cb.message.edit_text("🔑 Eski parolni kiriting:")
    await cb.answer()


@router.message(PwChange.old_pw)
async def pw_old(message: Message, state: FSMContext, db_user: User):
    await message.delete()
    if not db_user.check_pw(message.text.strip()):
        await message.answer("❌ Eski parol noto'g'ri."); return
    await state.set_state(PwChange.new_pw)
    await message.answer("🔑 Yangi parolni kiriting (kamida 6 belgi):")


@router.message(PwChange.new_pw)
async def pw_new(message: Message, state: FSMContext):
    await message.delete()
    pw = message.text.strip()
    if len(pw) < 6:
        await message.answer(T.PW_SHORT, parse_mode="HTML"); return
    await state.update_data(new_pw=pw)
    await state.set_state(PwChange.confirm)
    await message.answer("🔑 Yangi parolni tasdiqlang:")


@router.message(PwChange.confirm)
async def pw_confirm(message: Message, state: FSMContext, session, db_user: User):
    await message.delete()
    data = await state.get_data()
    if message.text.strip() != data["new_pw"]:
        await message.answer(T.PW_MISMATCH, parse_mode="HTML"); return
    db_user.set_pw(data["new_pw"])
    await session.commit(); await state.clear()
    cfg = await current_cfg(session, db_user.organization_id)
    has_ocr = cfg.allow_ocr if cfg else False
    await message.answer("✅ Parol o'zgartirildi.", reply_markup=main_menu(db_user.role, has_ocr))


@router.message(F.text == "📜 Tarixim")
async def history(message: Message, session, db_user: User):
    r = await session.execute(
        select(Nakladnaya).where(Nakladnaya.creator_id == db_user.id)
        .order_by(Nakladnaya.created_at.desc()).limit(15)
    )
    docs = r.scalars().all()
    if not docs:
        await message.answer(T.HISTORY_EMPTY, parse_mode="HTML"); return

    cfg = await current_cfg(session, db_user.organization_id)
    lines = [T.HISTORY_HDR]
    for d in docs:
        date_s = d.created_at.strftime("%d.%m.%Y") if d.created_at else ""
        icon   = "✅" if d.status.value == "received" else "📄"
        src    = "📸" if d.source == "ocr" else ""
        lines.append(f"{icon}{src} <b>№{d.number}</b> — {date_s} | {len(d.items)} ta\n")
    await message.answer("".join(lines), parse_mode="HTML")

    # Oxirgi nakladnoyning preview'ini ko'rsatish
    if docs:
        last = docs[0]
        org = await session.get(Organization, last.organization_id)
        preview = build_preview(last, org.name if org else "")
        from aiogram.types import BufferedInputFile
        await message.answer_photo(
            BufferedInputFile(preview, "last_nak.png"),
            caption=f"🖼 So'nggi: <b>№{last.number}</b>",
            parse_mode="HTML",
            reply_markup=nakladnoy_view_kb(
                last.id,
                cfg.allow_excel if cfg else True,
                cfg.allow_word if cfg else False,
                cfg.allow_pdf if cfg else False,
            )
        )
