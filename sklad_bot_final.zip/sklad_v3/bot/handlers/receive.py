import datetime
from aiogram import F, Router
from aiogram.types import Message
from sqlalchemy import select
from bot.models import DocStatus, Nakladnaya, User
from bot.services.audit import log
from bot import texts as T

router = Router(name="receive")


@router.message(F.text.startswith("/qabul"))
async def qabul(message: Message, session, db_user: User):
    parts = message.text.split()
    if len(parts) != 3:
        await message.answer("Foydalanish: /qabul <raqam> <pin>\nMasalan: /qabul 0001/2026 1234")
        return
    _, number, pin = parts
    r = await session.execute(select(Nakladnaya).where(
        Nakladnaya.organization_id == db_user.organization_id, Nakladnaya.number == number))
    nak = r.scalar_one_or_none()
    if not nak or nak.pin != pin:
        await message.answer(T.QABUL_FAIL, parse_mode="HTML"); return
    if nak.status == DocStatus.RECEIVED:
        await message.answer(f"ℹ️ №{number} allaqachon qabul qilingan."); return
    nak.status = DocStatus.RECEIVED
    nak.received_at = datetime.datetime.now(datetime.timezone.utc)
    await log(session, db_user.id, db_user.organization_id, "nak_receive", number)
    await session.commit()
    await message.answer(T.QABUL_OK.format(number=number), parse_mode="HTML")
