"""Rasm → Excel (OCR) — Gemini orqali."""
import os, random
import datetime as dt
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, FSInputFile, Message

from bot import texts as T
from bot.keyboards import main_menu, ocr_confirm_kb
from bot.models import Nakladnaya, NakItem, User
from bot.services.documents.excel_doc import build_excel
from bot.services.documents.generate import GEN
from bot.services.documents.preview import build_preview
from bot.services.audit import log
from bot.services.numbering import next_number
from bot.services.subscription import current_cfg
from bot.states import OCR

router = Router(name="ocr")


@router.message(F.text == "📸 Rasm → Excel")
async def ocr_start(message: Message, state: FSMContext, session, db_user: User):
    cfg = await current_cfg(session, db_user.organization_id)
    if not cfg or not cfg.allow_ocr:
        await message.answer(
            "📸 <b>Rasm → Excel funksiyasi</b>\n\n"
            "Bu funksiya sizning tarifingizda mavjud emas.\n"
            "Administratorga murojaat qiling.",
            parse_mode="HTML"
        )
        return

    from bot.config import settings
    if not settings.GEMINI_API_KEY:
        await message.answer(
            "⚙️ GEMINI_API_KEY sozlanmagan.\n"
            "Administrator .env faylga kalit qo'shishi kerak."
        )
        return

    await state.set_state(OCR.waiting_photo)
    await message.answer(T.OCR_PROMPT, parse_mode="HTML")


@router.message(OCR.waiting_photo, F.photo)
async def ocr_photo(message: Message, state: FSMContext, session, db_user: User):
    wait_msg = await message.answer(T.OCR_PROCESSING, parse_mode="HTML")
    try:
        photo   = message.photo[-1]
        file    = await message.bot.get_file(photo.file_id)
        io_bytes = await message.bot.download_file(file.file_path)
        img_data = io_bytes.read() if hasattr(io_bytes, "read") else bytes(io_bytes)

        from bot.services.gemini_service import ocr_nakladnaya
        data = await ocr_nakladnaya(img_data)
        await state.update_data(ocr_data=data)
        await state.set_state(OCR.confirm)

        items = data.get("items", [])
        preview_lines = "\n".join(
            f"  {i+1}. <code>{it.get('code','—')}</code> | "
            f"{it.get('name','')} — {it.get('quantity','')} {it.get('unit','')}"
            for i, it in enumerate(items[:15])
        )
        preview_text = (
            f"🏗 Obyekt: <b>{data.get('object_text') or '—'}</b>\n"
            f"👤 Jo'natuvchi: <b>{data.get('sender') or '—'}</b>\n"
            f"👤 Qabul: <b>{data.get('receiver') or '—'}</b>\n\n"
            f"📦 Mahsulotlar (<b>{len(items)} ta</b>):\n{preview_lines}"
        )

        await wait_msg.delete()
        await message.answer(
            T.OCR_CONFIRM.format(preview=preview_text),
            reply_markup=ocr_confirm_kb(), parse_mode="HTML"
        )

    except Exception as e:
        await wait_msg.delete()
        await message.answer(
            f"❌ Rasm o'qishda xato: {e}\n\n"
            "Sifatliroq rasm yuboring (yorug', aniq, to'g'ri burchakdan)."
        )
        await state.clear()


@router.message(OCR.waiting_photo)
async def ocr_not_photo(message: Message):
    await message.answer("📸 Iltimos, rasm yuboring (foto).")


@router.callback_query(OCR.confirm, F.data == "ocr:cancel")
async def ocr_cancel(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    await state.clear()
    cfg = await current_cfg(session, db_user.organization_id)
    has_ocr = cfg.allow_ocr if cfg else False
    await cb.message.edit_text("❌ Bekor qilindi.")
    await cb.message.answer(T.MAIN_MENU, reply_markup=main_menu(db_user.role, has_ocr), parse_mode="HTML")
    await cb.answer()


@router.callback_query(OCR.confirm, F.data == "ocr:confirm")
async def ocr_confirm_handler(cb: CallbackQuery, state: FSMContext, session, db_user: User):
    from bot.models import Organization
    ocr_data = (await state.get_data()).get("ocr_data", {})
    org      = await session.get(Organization, db_user.organization_id)

    number = await next_number(session, db_user.organization_id)
    nak = Nakladnaya(
        number=number, organization_id=db_user.organization_id,
        creator_id=db_user.id, doc_type="chiqim",
        object_text=ocr_data.get("object_text", ""),
        sender=ocr_data.get("sender", ""),
        receiver=ocr_data.get("receiver", ""),
        template_id=1,
        pin=f"{random.randint(0, 9999):04d}",
        source="ocr",
    )
    for i, it in enumerate(ocr_data.get("items", []), 1):
        nak.items.append(NakItem(
            row_no=i, code=it.get("code", ""),
            name=it.get("name", ""), unit=it.get("unit", ""),
            quantity=it.get("quantity", "")
        ))
    session.add(nak)
    await session.flush()
    await log(session, db_user.id, db_user.organization_id, "ocr_create", number)
    await session.commit()
    nak.created_at = dt.datetime.now()

    # Excel fayl
    xl_path = os.path.join(GEN, f"ocr_{number.replace('/', '-')}.xlsx")
    build_excel(nak, org.name if org else "", xl_path, 1)
    await cb.message.answer_document(
        FSInputFile(xl_path),
        caption=f"✅ <b>OCR №{number} — Excel tayyorlandi!</b>", parse_mode="HTML"
    )

    # Preview rasm
    preview_bytes = build_preview(nak, org.name if org else "")
    await cb.message.answer_photo(
        BufferedInputFile(preview_bytes, f"ocr_{number.replace('/', '-')}.png"),
        caption=f"🖼 <b>Ko'rinishi</b>", parse_mode="HTML"
    )

    await state.clear()
    cfg = await current_cfg(session, db_user.organization_id)
    has_ocr = cfg.allow_ocr if cfg else False
    await cb.message.answer(T.MAIN_MENU, reply_markup=main_menu(db_user.role, has_ocr), parse_mode="HTML")
    await cb.answer()
