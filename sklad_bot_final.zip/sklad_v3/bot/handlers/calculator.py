"""
Hisoblash — 2 ta rejim:
1. Oddiy kalkulator — matematik ifoda (barcha tarif)
2. AI kalkulator (Gemini) — tabiiy tilda (admin belgilagan tarif)
"""
import ast, math, operator
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardButton as IB, InlineKeyboardMarkup as IM, Message
from bot import texts as T
from bot.keyboards import main_menu
from bot.models import User
from bot.states import Calc

router = Router(name="calculator")

# ── Oddiy hisoblash ──────────────────────────────────────────
OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow, ast.USub: operator.neg,
    ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv
}
FNS = {
    "sqrt": math.sqrt, "abs": abs, "round": round, "floor": math.floor,
    "ceil": math.ceil, "log": math.log, "log10": math.log10,
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "pi": math.pi, "e": math.e, "pow": pow
}


def _eval(node):
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in OPS:
        return OPS[type(node.op)](_eval(node.left), _eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in OPS:
        return OPS[type(node.op)](_eval(node.operand))
    if isinstance(node, ast.Call):
        fn = node.func.id if isinstance(node.func, ast.Name) else None
        if fn in FNS: return FNS[fn](*[_eval(a) for a in node.args])
    if isinstance(node, ast.Name) and node.id in FNS: return FNS[node.id]
    raise ValueError("Ruxsat etilmagan ifoda")


def simple_calc(expr: str) -> str:
    try:
        expr2 = expr.replace(",", ".").replace("×", "*").replace("÷", "/").replace("^", "**")
        result = _eval(ast.parse(expr2.strip(), mode="eval").body)
        if isinstance(result, float) and result.is_integer(): result = int(result)
        if isinstance(result, (int, float)):
            fmt = f"{result:,.2f}".rstrip("0").rstrip(".") if isinstance(result, float) else f"{result:,}"
            fmt = fmt.replace(",", " ")
        else:
            fmt = str(result)
        return f"🧮 <code>{expr}</code>\n= <b>{fmt}</b>"
    except ZeroDivisionError:
        return "❌ Nolga bo'lish mumkin emas."
    except Exception:
        return None  # AI kalkulatorga uzatish uchun


def calc_mode_kb(has_ai: bool) -> IM:
    rows = [[IB(text="🔢 Oddiy hisoblash", callback_data="calc_mode:simple")]]
    if has_ai:
        rows.append([IB(text="🤖 AI hisoblash (Gemini)", callback_data="calc_mode:ai")])
    rows.append([IB(text="🔙 Orqaga", callback_data="calc_mode:back")])
    return IM(inline_keyboard=rows)


# ── Handlerlar ───────────────────────────────────────────────

@router.message(F.text == "🧮 Hisoblash")
async def calc_open(message: Message, state: FSMContext, session, db_user: User):
    from bot.services.subscription import current_cfg
    cfg = await current_cfg(session, db_user.organization_id)

    allow_calc    = cfg.allow_calc    if cfg else True
    allow_ai_calc = cfg.allow_ai_calc if cfg else False

    if not allow_calc and not allow_ai_calc:
        await message.answer("🧮 Hisoblash funksiyasi sizning tarifingizda mavjud emas.")
        return

    has_ai = allow_ai_calc and bool(__import__('bot.config', fromlist=['settings']).settings.GEMINI_API_KEY)

    await message.answer(
        "🧮 <b>Hisoblash</b>\n\nQaysi rejimda ishlaysiz?",
        reply_markup=calc_mode_kb(has_ai), parse_mode="HTML"
    )


@router.callback_query(F.data == "calc_mode:back")
async def calc_back(cb, db_user: User):
    from bot.services.subscription import current_cfg
    await cb.message.edit_text("Bosh menyu")
    await cb.message.answer(T.MAIN_MENU, reply_markup=main_menu(db_user.role), parse_mode="HTML")
    await cb.answer()


@router.callback_query(F.data == "calc_mode:simple")
async def calc_simple_start(cb, state: FSMContext):
    await state.update_data(calc_mode="simple")
    await state.set_state(Calc.expr)
    await cb.message.edit_text(
        "🔢 <b>Oddiy hisoblash</b>\n\n"
        "<b>Misollar:</b>\n"
        "• <code>125 * 48</code>\n"
        "• <code>1500 / 12 + 300</code>\n"
        "• <code>sqrt(144)</code>\n"
        "• <code>25 ** 2</code> (25 kvadrat)\n"
        "• <code>1500000 * 0.12</code>\n\n"
        "Chiqish: /menu",
        parse_mode="HTML"
    )
    await cb.answer()


@router.callback_query(F.data == "calc_mode:ai")
async def calc_ai_start(cb, state: FSMContext):
    await state.update_data(calc_mode="ai")
    await state.set_state(Calc.expr)
    await cb.message.edit_text(
        "🤖 <b>AI hisoblash (Gemini)</b>\n\n"
        "Savolingizni oddiy so'z bilan yozing:\n\n"
        "<b>Misollar:</b>\n"
        "• <code>100 metr truba uchun har 5 metrda 1 birikma kerak, nechta?</code>\n"
        "• <code>50 xalta sement, har xalta 50 kg, jami necha tonna?</code>\n"
        "• <code>12 ta ishchi 8 soat ishlaydi, 3 kun uchun umumiy soat?</code>\n"
        "• <code>Kvadrat metrni kvadrat santimetrga o'tkazish formulasi?</code>\n\n"
        "⏳ AI javob berishi 2-3 soniya oladi.\n"
        "Chiqish: /menu",
        parse_mode="HTML"
    )
    await cb.answer()


@router.message(Calc.expr)
async def calc_expr(message: Message, state: FSMContext, session, db_user: User):
    if message.text.strip().lower() in ("/menu", "🏠", "menu"):
        await state.clear()
        await message.answer(T.MAIN_MENU, reply_markup=main_menu(db_user.role), parse_mode="HTML")
        return

    data = await state.get_data()
    mode = data.get("calc_mode", "simple")
    expr = message.text.strip()

    if mode == "ai":
        # AI kalkulator
        from bot.config import settings
        if not settings.GEMINI_API_KEY:
            await message.answer("❌ GEMINI_API_KEY sozlanmagan.")
            return
        wait_msg = await message.answer("⏳ Gemini hisoblayapti...")
        try:
            from bot.services.gemini_service import ai_calculate
            result = await ai_calculate(expr)
            await wait_msg.delete()
            await message.answer(
                f"🤖 <b>AI Hisoblash natijasi:</b>\n\n{result}",
                parse_mode="HTML"
            )
        except Exception as e:
            await wait_msg.delete()
            await message.answer(f"❌ AI xato: {e}\n\nOddiy hisoblashga o'tmoqdasiz...")
            result = simple_calc(expr)
            if result:
                await message.answer(result, parse_mode="HTML")
    else:
        # Oddiy kalkulator
        result = simple_calc(expr)
        if result:
            await message.answer(result, parse_mode="HTML")
        else:
            # Oddiy kalkulator uddalay olmasa AI ga uzatib ko'rish
            from bot.config import settings
            if settings.GEMINI_API_KEY:
                wait_msg = await message.answer("⏳ AI hisoblayapti...")
                try:
                    from bot.services.gemini_service import ai_calculate
                    ai_result = await ai_calculate(expr)
                    await wait_msg.delete()
                    await message.answer(
                        f"🤖 <b>AI natija:</b>\n\n{ai_result}",
                        parse_mode="HTML"
                    )
                except Exception:
                    await wait_msg.delete()
                    await message.answer(T.CALC_ERR, parse_mode="HTML")
            else:
                await message.answer(T.CALC_ERR, parse_mode="HTML")
