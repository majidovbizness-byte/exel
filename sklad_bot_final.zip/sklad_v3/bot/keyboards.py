"""Барча тугмалар."""
from aiogram.types import (
    InlineKeyboardButton as IB, InlineKeyboardMarkup as IM,
    KeyboardButton as KB, ReplyKeyboardMarkup as RM, ReplyKeyboardRemove
)
from bot.models import UserRole, SubPlan, PlanConfig


TEMPLATES_NAMES = {
    1: "Klassik", 2: "Ixcham", 3: "Korporativ", 4: "Batafsil",
    5: "Sodda", 6: "Mahsulot", 7: "Transport", 8: "Ikki tilli",
    9: "A5 kichik", 10: "Qurilish"
}


def rm() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()


def contact_kb() -> RM:
    return RM(keyboard=[[KB(text="📱 Telefon raqamni yuborish", request_contact=True)]],
              resize_keyboard=True, one_time_keyboard=True)


def main_menu(role: UserRole, has_ocr: bool = False) -> RM:
    rows = [
        [KB(text="🆕 Yangi nakladnoy"), KB(text="🧮 Hisoblish")],
        [KB(text="📜 Tarixim"),          KB(text="⚙️ Sozlamalar")],
    ]
    if has_ocr:
        rows.insert(1, [KB(text="📸 Rasm → Excel")])
    if role in (UserRole.ADMIN, UserRole.SUPER_ADMIN):
        rows.append([KB(text="🛠 Admin panel")])
    if role == UserRole.MANAGER:
        rows.append([KB(text="📊 Hisobot")])
    return RM(keyboard=rows, resize_keyboard=True)


# ── Nakladnoy ──────────────────────────────────────────────────────

def doc_type_kb() -> IM:
    return IM(inline_keyboard=[
        [IB(text="📤 Chiqim (skladdan)", callback_data="dt:chiqim")],
        [IB(text="↩️ Qaytarish (obyektdan)", callback_data="dt:qaytarish")],
    ])


def skip_or_blank_kb(cb: str = "skip") -> IM:
    """O'tkazish yoki bo'sh (yozma shaklda ___) kiritish."""
    return IM(inline_keyboard=[
        [IB(text="⏭ O'tkazish", callback_data=cb)],
        [IB(text="✏️ Bo'sh qoldirish (___)", callback_data=f"{cb}_blank")],
    ])


def units_kb() -> IM:
    units = ["шт", "кг", "литр", "м", "м²", "тонна", "к-т", "п.м", "рулон", "упак"]
    rows = [[IB(text=u, callback_data=f"unit:{u}") for u in units[i:i+4]]
            for i in range(0, len(units), 4)]
    return IM(inline_keyboard=rows)


def search_results_kb(materials: list) -> IM:
    rows = [[IB(text=f"📦 {m.code} — {m.name[:38]}", callback_data=f"mat:{m.id}")]
            for m in materials[:8]]
    rows.append([IB(text="✏️ Qo'lda kiritish (kodsiz)", callback_data="mat:manual")])
    return IM(inline_keyboard=rows)


def more_items_kb(count: int) -> IM:
    return IM(inline_keyboard=[
        [IB(text=f"➕ Yana mahsulot qo'shish ({count} ta qo'shildi)", callback_data="more:yes")],
        [IB(text="✅ Tugatish → Davom etish", callback_data="more:no")],
    ])


def template_kb(max_tpl: int = 10) -> IM:
    TEMPLATES = [
        (1,  "📋 Klassik (standart)"),
        (2,  "📄 Ixcham"),
        (3,  "🏢 Korporativ"),
        (4,  "📊 Batafsil (barcha ustunlar)"),
        (5,  "✅ Sodda (imzo qatori katta)"),
        (6,  "📦 Mahsulot-markazlashgan"),
        (7,  "🚛 Transport ma'lumotlari katta)"),
        (8,  "🌐 Ikki tilli (Rus/O'zb)"),
        (9,  "📑 A5 format (kichik)"),
        (10, "🏗 Qurilish (loyiha ustunlari)"),
    ]
    rows = [[IB(text=lbl, callback_data=f"tpl:{tid}")]
            for tid, lbl in TEMPLATES[:max_tpl]]
    return IM(inline_keyboard=rows)


def format_kb(cfg: "PlanConfig | None") -> IM:
    rows = []
    if not cfg or cfg.allow_excel:
        rows.append([IB(text="📊 Excel (.xlsx)", callback_data="fmt:excel")])
    if cfg and cfg.allow_word:
        rows.append([IB(text="📄 Word (.docx)", callback_data="fmt:word")])
    if cfg and cfg.allow_pdf:
        rows.append([IB(text="🧾 PDF", callback_data="fmt:pdf")])
    if not rows:
        rows.append([IB(text="📊 Excel (.xlsx)", callback_data="fmt:excel")])
    return IM(inline_keyboard=rows)


def confirm_kb() -> IM:
    return IM(inline_keyboard=[
        [IB(text="✅ Tasdiqlash va yaratish", callback_data="confirm:yes")],
        [IB(text="✏️ Tahrirlash (qaytish)", callback_data="confirm:edit")],
        [IB(text="❌ Bekor qilish", callback_data="confirm:no")],
    ])


def plans_display_kb(cfgs: list) -> IM:
    rows = [[IB(text=f"{'📋' if c.plan==SubPlan.BASIC else '📊' if c.plan==SubPlan.STANDARD else '🏆'} "
                    f"{c.name or c.plan.value.capitalize()} — {c.price:,.0f} {c.currency}",
                callback_data=f"plan:{c.plan.value}")]
            for c in cfgs]
    return IM(inline_keyboard=rows)


def nakladnoy_view_kb(nak_id: int, fmt_excel: bool, fmt_word: bool, fmt_pdf: bool) -> IM:
    rows = [[IB(text="🖼 Rasm ko'rinishi", callback_data=f"view:preview:{nak_id}")]]
    dl = []
    if fmt_excel: dl.append(IB(text="📊 Excel", callback_data=f"view:excel:{nak_id}"))
    if fmt_word:  dl.append(IB(text="📄 Word",  callback_data=f"view:word:{nak_id}"))
    if fmt_pdf:   dl.append(IB(text="🧾 PDF",   callback_data=f"view:pdf:{nak_id}"))
    if dl: rows.append(dl)
    rows.append([IB(text="🗑 O'chirish", callback_data=f"view:del:{nak_id}")])
    return IM(inline_keyboard=rows)


# ── Admin ──────────────────────────────────────────────────────────

def admin_menu_kb() -> IM:
    return IM(inline_keyboard=[
        [IB(text="👥 Foydalanuvchilar",       callback_data="adm:users")],
        [IB(text="📦 Mahsulot bazasi",         callback_data="adm:mat")],
        [IB(text="🚛 Transport bazasi",        callback_data="adm:veh")],
        [IB(text="💳 Obuna boshqaruvi",        callback_data="adm:sub")],
        [IB(text="⚙️ Tarif sozlamalari",       callback_data="adm:plans")],
        [IB(text="📊 Hisobot va statistika",   callback_data="adm:report")],
        [IB(text="📒 Audit jurnali",           callback_data="adm:audit")],
        [IB(text="⚠️ Shubhali harakatlar",     callback_data="adm:suspicious")],
        [IB(text="🏗 Tashkilot sozlamalari",   callback_data="adm:org")],
    ])


def users_menu_kb() -> IM:
    return IM(inline_keyboard=[
        [IB(text="➕ Yangi xodim qo'shish",     callback_data="usr:add")],
        [IB(text="📋 Barcha xodimlar ro'yxati", callback_data="usr:list")],
        [IB(text="🔴 Bloklash",                  callback_data="usr:block_menu")],
        [IB(text="🟢 Blokdan chiqarish",         callback_data="usr:unblock_menu")],
        [IB(text="⏸ Tekshiruv rejimiga qo'yish", callback_data="usr:freeze_menu")],
        [IB(text="📈 Xodim statistikasi",        callback_data="usr:stats")],
        [IB(text="🏆 Xodimlar reytingi",         callback_data="usr:rating")],
    ])


def mat_menu_kb() -> IM:
    return IM(inline_keyboard=[
        [IB(text="➕ Ko'plab qo'shish",  callback_data="mat:bulk")],
        [IB(text="🔍 Qidirish",          callback_data="mat:search")],
        [IB(text="🗑 O'chirish",          callback_data="mat:delete")],
        [IB(text="📊 Statistika",         callback_data="mat:stats")],
    ])


def plan_edit_kb(plan: SubPlan) -> IM:
    return IM(inline_keyboard=[
        [IB(text="✏️ Nomi",                callback_data=f"pe:name:{plan.value}")],
        [IB(text="📝 Tavsifi",             callback_data=f"pe:desc:{plan.value}")],
        [IB(text="💰 Narxi",               callback_data=f"pe:price:{plan.value}")],
        [IB(text="🔢 Limit (nakladnoy)",   callback_data=f"pe:limit:{plan.value}")],
        [IB(text="📊 Formatlar",           callback_data=f"pe:formats:{plan.value}")],
        [IB(text="🛠 Funksiyalar",          callback_data=f"pe:funcs:{plan.value}")],
        [IB(text="🤖 Gemini AI funksiyalar", callback_data=f"pe:ai:{plan.value}")],
        [IB(text="♾ Cheksiz qilish",       callback_data=f"pe:unlimited:{plan.value}")],
    ])


def formats_choice_kb(cfg: "PlanConfig") -> IM:
    def ico(val): return "✅" if val else "❌"
    return IM(inline_keyboard=[
        [IB(text=f"{ico(cfg.allow_excel)} Excel",  callback_data="fmt_tog:excel")],
        [IB(text=f"{ico(cfg.allow_word)}  Word",   callback_data="fmt_tog:word")],
        [IB(text=f"{ico(cfg.allow_pdf)}   PDF",    callback_data="fmt_tog:pdf")],
        [IB(text="✅ Saqlash",                     callback_data="fmt_tog:save")],
    ])


def funcs_choice_kb(cfg: "PlanConfig") -> IM:
    def ico(val): return "✅" if val else "❌"
    return IM(inline_keyboard=[
        [IB(text=f"{ico(cfg.allow_ocr)}       📸 Rasm→Excel (OCR)", callback_data="fn_tog:ocr")],
        [IB(text=f"{ico(cfg.allow_report)}    📊 Hisobot",          callback_data="fn_tog:report")],
        [IB(text=f"{ico(cfg.allow_transport)} 🚛 Transport bazasi", callback_data="fn_tog:transport")],
        [IB(text=f"{ico(cfg.allow_calc)}      🧮 Hisoblash",        callback_data="fn_tog:calc")],
        [IB(text=f"📋 Shablonlar soni: {cfg.allow_templates}", callback_data="fn_tog:templates")],
        [IB(text="✅ Saqlash",                                  callback_data="fn_tog:save")],
    ])


def back_to_admin() -> IM:
    return IM(inline_keyboard=[[IB(text="🔙 Admin panel", callback_data="adm:back")]])


def pw_change_kb() -> IM:
    return IM(inline_keyboard=[[IB(text="🔑 Parolni o'zgartirish", callback_data="pw:change")]])


def ocr_confirm_kb() -> IM:
    return IM(inline_keyboard=[
        [IB(text="✅ To'g'ri, Excel yaratish", callback_data="ocr:confirm")],
        [IB(text="❌ Bekor qilish",            callback_data="ocr:cancel")],
    ])


def ai_funcs_kb(cfg) -> IM:
    def ico(val): return "ON" if val else "OFF"
    return IM(inline_keyboard=[
        [IB(text=f"[{ico(cfg.allow_ai_calc)}] Hisoblash (AI)", callback_data="ai_tog:ai_calc")],
        [IB(text=f"[{ico(cfg.allow_ai_chat)}] Aqlli suhbat",   callback_data="ai_tog:ai_chat")],
        [IB(text=f"[{ico(cfg.allow_ai_search)}] AI qidiruv",   callback_data="ai_tog:ai_search")],
        [IB(text=f"[{ico(cfg.allow_ai_report)}] AI hisobot",   callback_data="ai_tog:ai_report")],
        [IB(text=f"[{ico(cfg.allow_ai_anomaly)}] Anomaliya",   callback_data="ai_tog:ai_anomaly")],
        [IB(text=f"[{ico(cfg.allow_ai_briefing)}] Kunlik brifing", callback_data="ai_tog:ai_briefing")],
        [IB(text=f"[{ico(cfg.allow_ai_voice)}] Ovozli buyruq", callback_data="ai_tog:ai_voice")],
        [IB(text=f"[{ico(cfg.allow_ai_translate)}] Ko'p til",  callback_data="ai_tog:ai_translate")],
        [IB(text="Saqlash", callback_data="ai_tog:save")],
    ])
