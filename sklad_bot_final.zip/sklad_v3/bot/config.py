from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    BOT_TOKEN: str
    DATABASE_URL: str
    SUPER_ADMIN_ID: int
    ORG_NAME: str = "ООО \"TO'PALANG HPD HOLDING\""
    ORG_OBJECT: str = ""
    GEMINI_API_KEY: str = ""

settings = Settings()
