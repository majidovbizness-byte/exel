"""Барча матнлар — расмий ўзбекча."""

WELCOME = (
    "🏭 <b>Sklad Nakladnoy Tizimi</b>\n\n"
    "Ushbu tizim orqali siz накладной hujjatlarini\n"
    "tez va xatosiz tuzib olishingiz mumkin.\n\n"
    "Kirish uchun <b>telefon raqamingizni</b> yuboring 👇"
)
ASK_PHONE       = "📱 <b>Telefon raqamni tasdiqlang</b>\n\nPastdagi tugmani bosing:"
ASK_NAME        = "👤 <b>To'liq ism-familiyangizni kiriting</b>\n\n<i>Masalan: Aliyev Vali Boboyevich</i>"
ASK_PW          = "🔐 <b>Parol o'rnating</b>\n\nKamida <b>6 ta belgi</b> kiriting.\nParolni yodda saqlang — keyingi kirishlarda kerak bo'ladi."
ASK_PW2         = "🔐 <b>Parolni tasdiqlang</b>\n\nParolni yana bir marta kiriting:"
PW_MISMATCH     = "❌ Parollar mos kelmadi. Qaytadan kiriting."
PW_SHORT        = "❌ Parol kamida 6 ta belgi bo'lishi kerak."
NOT_ALLOWED     = "🚫 Sizning raqamingiz tizimda ro'yxatdan o'tmagan.\n\nAdministratorga murojaat qiling."
BLOCKED         = "🔴 Hisobingiz bloklangan. Administrator bilan bog'laning."
FROZEN          = "⏸ Hisobingiz tekshiruv rejimida. Administrator bilan bog'laning."

REG_OK = (
    "✅ <b>Ro'yxatdan o'tish muvaffaqiyatli!</b>\n\n"
    "👤 Ism: <b>{name}</b>\n"
    "🔑 Login: <code>{username}</code>\n"
    "📱 Telefon: <b>{phone}</b>\n\n"
    "⚠️ Login va parolni saqlang — keyingi kirishda kerak bo'ladi.\n\n"
    "Endi <b>obuna tarifini tanlang</b> 👇"
)

MAIN_MENU      = "🏠 <b>Asosiy menyu</b>"
PLAN_CHOOSE    = "💳 <b>Obuna tarifini tanlang:</b>"
PLAN_EXPIRED_MSG = "⏰ <b>Obuna muddati tugagan.</b>\nAdministratorga murojaat qiling."
PLAN_LIMIT_MSG   = "⛔ <b>Obuna limiti tugadi ({used}/{limit}).</b>\nTarifni yangilang."

NAK_START      = "📄 <b>Yangi nakladnoy</b>\nHujjat turini tanlang:"
NAK_OBJ        = "🏗 <b>Obyekt nomini kiriting:</b>\n<i>(Oldingi: {prev})</i>\n\n«.» yuborsangiz oldingi saqlanadi."
NAK_SENDER     = "👤 <b>Jo'natuvchi:</b>\n<i>F.I.Sh. va lavozim kiriting</i>\n\nYoki: <code>________________</code> (bo'sh qoldirish uchun)"
NAK_RECEIVER   = "👤 <b>Qabul qiluvchi:</b>\n<i>F.I.Sh. va tashkilot kiriting</i>\n\nYoki: <code>________________</code> (bo'sh qoldirish uchun)"
NAK_VEHICLE    = "🚛 <b>Mashina davlat raqami:</b>\n<i>Masalan: 01 A 123 BC</i>"
NAK_VEH_FOUND  = "✅ Mashina topildi: <b>{model}</b>\nHaydovchi: <b>{driver}</b>"
NAK_VEH_MODEL  = "🚛 <b>Mashina rusumi:</b>\n<i>Masalan: Kamaz 6520</i>\n\nYoki: <code>________________</code>"
NAK_DRIVER     = "👨‍✈️ <b>Haydovchi F.I.Sh.:</b>\n\nYoki: <code>________________</code>"
NAK_DEST       = "📍 <b>Qayerga yuboriladi?</b>\n<i>Aniq manzil va tashkilot nomi</i>\n\nYoki: <code>________________</code>"
NAK_ITEM_PROMPT= (
    "📦 <b>Mahsulot qo'shing</b>\n\n"
    "▪ <b>Kod kiriting</b> (masalan <code>22551</code>) → bazadan topiladi\n"
    "▪ <b>Nom kiriting</b> (masalan <code>gayka</code>) → qidiradi\n\n"
    "Qo'shilganlar: <b>{count} ta</b>"
)
NAK_FOUND      = "✅ <b>{name}</b> ({unit})\n\nMiqdorini kiriting:"
NAK_NOT_FOUND  = "🔍 «{q}» bazada topilmadi. Birligini tanlang:"
NAK_QTY        = "🔢 <b>Miqdor kiriting:</b>"
NAK_ADDED      = "✅ Qo'shildi: <b>{name}</b> — {qty} {unit}"
NAK_CONFIRM    = (
    "📋 <b>Nakladnoy ma'lumotlarini tekshiring:</b>\n\n"
    "📄 Tur: <b>{dtype}</b>\n"
    "🏗 Obyekt: <b>{obj}</b>\n"
    "👤 Jo'natuvchi: <b>{sender}</b>\n"
    "👤 Qabul: <b>{receiver}</b>\n"
    "🚛 Mashina: <b>{veh}</b>\n"
    "👨‍✈️ Haydovchi: <b>{driver}</b>\n"
    "📍 Manzil: <b>{dest}</b>\n\n"
    "📦 Mahsulotlar — <b>{count} ta:</b>\n{items}\n\n"
    "Hammasi to'g'rimi?"
)
NAK_DONE = (
    "✅ <b>Nakladnoy №{number} tayyor!</b>\n\n"
    "🔑 Qabul PIN-kodi: <code>{pin}</code>\n"
    "Qabul qiluvchi: /qabul {number} {pin}"
)
QABUL_OK   = "✅ №{number} qabul qilindi."
QABUL_FAIL = "❌ PIN noto'g'ri yoki nakladnoy topilmadi."

OCR_PROMPT = (
    "📸 <b>Qo'lyozma nakladnoy rasmini yuboring</b>\n\n"
    "Bot rasmni o'qib, avtomatik Excel faylga aylantiradi.\n"
    "Sifatli, yaxshi yoritilgan rasm yuboring."
)
OCR_PROCESSING = "⏳ Rasm tahlil qilinmoqda..."
OCR_CONFIRM    = (
    "✅ <b>Rasm o'qildi — tekshiring:</b>\n\n"
    "{preview}\n\n"
    "To'g'ri bo'lsa — Excel yaratilsin:"
)

CALC_PROMPT = (
    "🧮 <b>Hisобlagich</b>\n\n"
    "<b>Misollar:</b>\n"
    "• <code>125 * 48</code>\n"
    "• <code>1500 / 12 + 300</code>\n"
    "• <code>sqrt(144)</code>\n"
    "• <code>25 ** 2</code>\n"
    "• <code>1500000 * 0.12</code>\n\n"
    "Chiqish: /menu"
)
CALC_ERR = "❌ Noto'g'ri ifoda. Qayta urinib ko'ring."

SETTINGS = (
    "⚙️ <b>Sozlamalar</b>\n\n"
    "👤 Ism: <b>{name}</b>\n"
    "🔑 Login: <code>{uname}</code>\n"
    "📱 Telefon: <b>{phone}</b>\n"
    "💼 Lavozim: <b>{pos}</b>\n"
    "🔐 Rol: <b>{role}</b>\n"
    "📊 Tarif: <b>{plan}</b> ({status})\n"
    "📄 Hujjatlar: <b>{used}/{limit}</b>\n"
    "👁 Oxirgi faollik: <b>{seen}</b>"
)

HISTORY_EMPTY = "📭 Sizda hali nakladnoy mavjud emas."
HISTORY_HDR   = "📜 <b>So'nggi 15 ta nakladnoy:</b>\n\n"

ADM_MENU    = "🛠 <b>Administrator paneli</b>\nBo'limni tanlang:"
ONLY_ADMIN  = "🚫 Faqat administrator uchun."
ONLY_MGR    = "🚫 Faqat rahbar/administrator uchun."
