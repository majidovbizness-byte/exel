from typing import Any, Callable
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from sqlalchemy import select
from bot.database import Session
from bot.models import User
import datetime


class AuthMiddleware(BaseMiddleware):
    OPEN = {"/start"}

    async def __call__(self, handler: Callable, event: TelegramObject, data: dict[str, Any]) -> Any:
        async with Session() as session:
            data["session"] = session
            tg_user = data.get("event_from_user")
            text = getattr(getattr(event, "message", None), "text", None)

            if tg_user and text not in self.OPEN:
                r = await session.execute(select(User).where(User.telegram_id == tg_user.id))
                user = r.scalar_one_or_none()
                data["db_user"] = user

                if user:
                    user.last_seen = datetime.datetime.now(datetime.timezone.utc)
                    await session.commit()

                    msg = (getattr(event, "message", None)
                           or getattr(getattr(event, "callback_query", None), "message", None))
                    if not user.is_active:
                        if msg: await msg.answer("🔴 Hisobingiz bloklangan.", parse_mode="HTML")
                        return
                    if user.is_frozen:
                        if msg: await msg.answer("⏸ Hisobingiz tekshiruv rejimida.", parse_mode="HTML")
                        return
            else:
                data["db_user"] = None

            return await handler(event, data)
