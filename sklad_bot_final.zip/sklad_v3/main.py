"""Bot ishga tushirish."""
import asyncio, logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from sqlalchemy import select

from bot.config import settings
from bot.database import Session, init_db
from bot.handlers import get_router
from bot.middlewares.auth import AuthMiddleware
from bot.models import Organization, Subscription, SubPlan, SubStatus, User, UserRole
from bot.services.subscription import ensure_default_plans

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
log = logging.getLogger(__name__)


async def bootstrap():
    async with Session() as s:
        r = await s.execute(select(User).where(User.telegram_id == settings.SUPER_ADMIN_ID))
        if r.scalar_one_or_none(): return

        r2 = await s.execute(select(Organization).where(Organization.name == settings.ORG_NAME))
        org = r2.scalar_one_or_none()
        if not org:
            org = Organization(name=settings.ORG_NAME, object_text=settings.ORG_OBJECT)
            s.add(org); await s.flush()
            s.add(Subscription(organization_id=org.id, plan=SubPlan.PREMIUM, status=SubStatus.ACTIVE))
        await ensure_default_plans(s, org.id)

        u = User(telegram_id=settings.SUPER_ADMIN_ID, phone="",
                 full_name="Bosh administrator", username="superadmin",
                 organization_id=org.id, role=UserRole.SUPER_ADMIN, is_active=True)
        u.set_pw("admin123")  # Birinchi kirishda o'zgartiring!
        s.add(u); await s.commit()
        log.info("Bosh administrator yaratildi (org_id=%s)", org.id)




async def daily_briefing_task(bot):
    import datetime
    while True:
        now = datetime.datetime.now()
        next_run = now.replace(hour=8, minute=0, second=0, microsecond=0)
        if now >= next_run:
            next_run += datetime.timedelta(days=1)
        wait_seconds = (next_run - now).total_seconds()
        await asyncio.sleep(wait_seconds)

        if not settings.GEMINI_API_KEY:
            continue
        try:
            from bot.database import Session as _S
            from bot.models import Nakladnaya as _N, Organization as _O
            from bot.models import Subscription as _Sub, User as _U
            from bot.services.subscription import get_plan_cfg as _gcfg
            from sqlalchemy import select as _sel, func as _f

            async with _S() as s:
                r = await s.execute(_sel(_O))
                orgs = r.scalars().all()
                for org in orgs:
                    sub_r = await s.execute(_sel(_Sub).where(_Sub.organization_id == org.id))
                    sub = sub_r.scalar_one_or_none()
                    if not sub: continue
                    cfg = await _gcfg(s, org.id, sub.plan)
                    if not cfg or not cfg.allow_ai_briefing: continue

                    today = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
                    r2 = await s.execute(_sel(_f.count()).select_from(_N).where(
                        _N.organization_id == org.id, _N.created_at >= today))
                    total = r2.scalar_one()

                    r3 = await s.execute(
                        _sel(_N.creator_id, _f.count()).where(
                            _N.organization_id == org.id, _N.created_at >= today)
                        .group_by(_N.creator_id))
                    by_user = []
                    for uid, cnt in r3.all():
                        u = await s.get(_U, uid)
                        by_user.append({"xodim": u.full_name if u else str(uid), "count": cnt})

                    from bot.services.gemini_service import ai_daily_briefing
                    briefing = await ai_daily_briefing({
                        "sana": datetime.datetime.now().strftime("%d.%m.%Y"),
                        "nakladnoylar": total,
                        "xodimlar": by_user,
                    })

                    admins = await s.execute(
                        _sel(_U).where(
                            _U.organization_id == org.id,
                            _U.is_active == True,
                        ))
                    for admin in admins.scalars():
                        if admin.role.value not in ("admin", "super_admin"):
                            continue
                        try:
                            await bot.send_message(
                                admin.telegram_id,
                                f"<b>Kunlik brifing {datetime.datetime.now().strftime('%d.%m.%Y')}</b>\n\n{briefing}",
                                parse_mode="HTML"
                            )
                        except Exception:
                            pass
        except Exception as e:
            log.error("Kunlik brifing xato: %s", e)

async def main():
    await init_db()
    await bootstrap()
    bot = Bot(token=settings.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp  = Dispatcher(storage=MemoryStorage())
    dp.update.outer_middleware(AuthMiddleware())
    dp.include_router(get_router())
    log.info("Bot ishga tushdi ✅")
    await bot.delete_webhook(drop_pending_updates=True)
    asyncio.create_task(daily_briefing_task(bot))
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
